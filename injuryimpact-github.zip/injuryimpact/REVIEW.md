# Module 1 review notes

Not run in the sandbox (no SQLAlchemy/pytest available): test_schema, test_sql_parity, test_pipeline, `cli demo`.
Run `pip install -e .[dev] && pytest` first.

## Likely problems
1. Config/mock paths resolve relative to the source tree (`parents[2]`); a non-editable install breaks. Use INJURYIMPACT_CONFIG_DIR or ship as package data.
2. SQLite returns naive datetimes for `DateTime(timezone=True)`; comparing with aware ones raises TypeError. pipeline.py normalises with `_aware()`; keep everything UTC.
3. `weights_version` fingerprint hashes raw file bytes, so a comment or whitespace edit changes the version without changing any score.
4. `load_settings` raises bare KeyError (not ConfigError) when scheduler/recovery/validation keys are missing.
5. SQL parity test checks table and column names only, not types, constraints or indexes. Known drift: unnamed UNIQUE constraints (PG names them differently from the models' `uq_` convention); 002 indexes `fetched_at DESC`, models do not; running `create_all` and 002 on Postgres would create duplicate indexes.
6. `.env` is never loaded: `get_database_url` reads os.environ but nothing calls `load_dotenv_if_available()`.
7. `club.method` and `scale_max` vs defaults are not validated.

## Design notes
- `external_ids.internal_id` and `change_log.entity_id` have no FK (polymorphic), so orphans are possible.
- A stale-report rule keyed on `reported_at` flags long-term injuries reported once; staleness should use last-confirmed time.
- If a player's injury type changes, the row is updated in place, so reinjury detection only sees deactivated rows.
- goal_contribution_share = (goals + assists) / team goals can exceed 1 (clamped).
- apscheduler, requests, scipy, psycopg are declared but unused so far.

## Module 2 added
adapters/ (base + mock), normalise.py, recovery.py, impact.py (pure), pipeline.py + cli.py (DB glue),
config/recovery_ranges.yaml (PLACEHOLDER values, unsourced), data/mock (fictional clubs and players),
scripts/make_mock_data.py, tests for each.

## Module 3 added
budget.py, planning.py (pure) | adapters/api_football.py | sync.py, scheduler.py (DB glue) | cli: sync, snapshot, check-api | tests/test_api_football.py, test_planning_and_budget.py (run), test_sync.py (not run: needs SQLAlchemy).
The live API adapter is written from documentation, never run against the real service.
