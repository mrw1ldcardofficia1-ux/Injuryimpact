# InjuryImpact

Premier League injury data pipeline + Impact Score engine, published as a free static website on GitHub Pages.

## Launch in 5 minutes (demo site, no accounts needed)
1. Create a new **empty** repo on GitHub (e.g. `injuryimpact`). Don't add a README there.
2. From this folder:
   ```bash
   git init -b main
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR-USERNAME/injuryimpact.git
   git push -u origin main
   ```
3. In the repo: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Go to the **Actions** tab, open **update-and-deploy**, and click **Run workflow** (or just wait for the push run).
5. Your site appears at `https://YOUR-USERNAME.github.io/injuryimpact/` (the workflow log prints the exact URL).

Until you add secrets, the site shows **demo data** (fictional clubs and players) and says so on the page.

## Go live with real data
See [DEPLOY.md](DEPLOY.md). In short: add repo secrets `DATABASE_URL` (Supabase Postgres) and
`API_FOOTBALL_KEY` under **Settings → Secrets and variables → Actions**, then re-run the workflow.
Test locally first with `python -m injuryimpact.cli check-api`.

## Local use
```bash
pip install -e .[dev]
pytest
python -m injuryimpact.cli demo      # prints scores from the mock feed
python -m injuryimpact.cli export    # writes site/data/latest.json
python -m http.server -d site        # open http://localhost:8000
```

## Known caveats
See [REVIEW.md](REVIEW.md) and the "Known limits" in DEPLOY.md. The live API adapter has not been run against the real service yet.
