# Go live for about $0

## One-time setup
1. **Database (free):** create a Supabase project. Copy the connection string and use the `postgresql+psycopg://...` form
   with `?sslmode=require`. Tables are created automatically on the first run (do not also run the migration SQL files).
2. **API key (free):** create an API-Football account at api-football.com, copy the key (100 calls/day).
3. **Try it locally first:**
   `cp .env.example .env`, fill both values, then `pip install -e .[dev]` and
   `python -m injuryimpact.cli check-api`. This checks your key, plan, today's usage and fetches injuries once (1 call).
   If it reports a "plan" error, the free plan does not cover the season in config/settings.yaml: change
   `api_football_season` or upgrade. Then `python -m injuryimpact.cli sync` and `python -m injuryimpact.cli snapshot`.
4. **GitHub:** push the repo, set Pages source to "GitHub Actions", add secrets `DATABASE_URL` and `API_FOOTBALL_KEY`.

## What runs, and what it costs in API calls
- Every 4 hours: 1 injuries call. Daily: standings + fixtures (2 calls) and player stats (about 25 to 35 pages).
  Weekly: teams + 20 squads. First run is about 55 calls. Normal runs stop at 90 calls/day.
- Matchday "fast mode" (injuries every 30 minutes) needs an always-on machine running
  `python -m injuryimpact.scheduler`; GitHub's free cron is too coarse and unreliable for that. It is optional.

## Known limits
- The API gives no injury start date or date of birth, so start = the day we first saw the injury and the age modifier is not applied.
- Fixture difficulty comes from current league position (strong opponent = harder).
- Raw API responses are not stored yet.
- Live-API code was written from documentation and has not been run against the real service: run `check-api` first.
