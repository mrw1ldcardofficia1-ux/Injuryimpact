from datetime import datetime, timezone

import pytest

from injuryimpact.adapters import AdapterError, ApiFootballAdapter
from injuryimpact.budget import Budget, BudgetExceeded
from injuryimpact.config import load_settings
from injuryimpact.types import InjuryStatus, Position

S = load_settings()
NOW = datetime(2026, 10, 22, 12, tzinfo=timezone.utc)


class Resp:
    def __init__(self, body, code=200):
        self._b, self.status_code = body, code

    def json(self):
        return self._b


class FakeHttp:
    """Routes by endpoint; a list value is consumed one page per call."""
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def get(self, url, headers=None, params=None, timeout=None):
        ep = url.rsplit("/v3.football.api-sports.io/", 1)[-1].replace("https://v3.football.api-sports.io/", "")
        self.calls.append((ep, dict(params or {}), dict(headers or {})))
        r = self.routes[ep]
        r = r.pop(0) if isinstance(r, list) else r
        return r if isinstance(r, Resp) else Resp(r)


def make(routes, limit=100, mode="normal"):
    b = Budget(limit, 0.9, 0.98)
    http = FakeHttp(routes)
    a = ApiFootballAdapter(S.providers["api_football"], 2026, "2026-27", b, mode=mode, api_key="k", http=http,
                           sleep=lambda s: None, min_interval=0, now=lambda: NOW)
    return a, b, http


TEAMS = {"response": [{"team": {"id": 33, "name": "Alpha FC", "code": "ALP"}}, {"team": {"id": 34, "name": "Beta Town", "code": None}}]}


def test_clubs_use_code_or_unique_fallback_and_send_key():
    a, b, http = make({"teams": TEAMS})
    clubs = a.fetch_clubs()
    assert [(c.provider_club_id, c.short_name) for c in clubs] == [("33", "ALP"), ("34", "BET34")]
    assert http.calls[0][2] == {"x-apisports-key": "k"} and http.calls[0][1] == {"league": 39, "season": 2026}
    a.fetch_clubs()
    assert len(http.calls) == 1 and b.used == 1                  # teams call is cached within a run


def test_squads_map_positions_and_flag_unknown():
    squad = {"response": [{"players": [{"id": 1, "name": "A. One", "position": "Goalkeeper"},
                                       {"id": 2, "name": "B. Two", "position": "Attacker"},
                                       {"id": 3, "name": "C. Three", "position": "Coach"}]}]}
    a, b, _ = make({"teams": TEAMS, "players/squads": [squad, squad]})
    ps = a.fetch_players()
    assert b.used == 3 and ps[0].position == Position.GK and ps[1].position == Position.FWD and ps[2].position is None
    assert any("unknown position" in w for w in a.warnings)


def test_injuries_dedupe_per_player_and_map_status():
    def row(pid, typ, date, reason="Hamstring Injury"):
        return {"player": {"id": pid, "name": f"P{pid}", "type": typ, "reason": reason}, "team": {"id": 33},
                "fixture": {"id": 1, "date": date}}
    body = {"response": [row(7, "Questionable", "2026-10-30T15:00:00+00:00"), row(7, "Missing Fixture", "2026-10-25T15:00:00+00:00"),
                         row(8, "Questionable", "2026-10-25T15:00:00+00:00"), row(9, "Suspended?", "2026-10-25T15:00:00+00:00")]}
    a, _, _ = make({"injuries": body})
    inj = {i.provider_player_id: i for i in a.fetch_injuries()}
    assert set(inj) == {"7", "8"}                                # unknown type skipped, never guessed
    assert inj["7"].status == InjuryStatus.OUT                   # soonest fixture's entry wins
    assert inj["8"].status == InjuryStatus.DOUBTFUL and inj["7"].reported_at == NOW
    assert inj["7"].start_date is None and inj["7"].source_url.startswith("https://") and any("unknown type" in w for w in a.warnings)


def test_api_error_inside_200_and_http_error():
    a, _, _ = make({"injuries": {"errors": {"plan": "Free plans do not have access to this season"}, "response": []}})
    with pytest.raises(AdapterError, match="plan"):
        a.fetch_injuries()
    a, b, _ = make({"injuries": Resp({}, 500)})
    with pytest.raises(AdapterError, match="500"):
        a.fetch_injuries()
    assert b.used == 1                                           # failed calls still count


STANDINGS = {"response": [{"league": {"standings": [[
    {"rank": 1, "team": {"id": 33}, "all": {"played": 9, "goals": {"for": 20}}},
    {"rank": 2, "team": {"id": 34}, "all": {"played": 9, "goals": {"for": 10}}},
    {"rank": 3, "team": {"id": 35}, "all": {"played": 8, "goals": {"for": 5}}}]]}}]}
FIXTURES = {"response": [
    {"fixture": {"id": 5, "date": "2026-10-24T14:00:00+00:00", "status": {"short": "NS"}}, "league": {"round": "Regular Season - 10"},
     "teams": {"home": {"id": 34}, "away": {"id": 33}}},
    {"fixture": {"id": 6, "date": "2026-10-17T14:00:00+00:00", "status": {"short": "FT"}}, "league": {"round": "Regular Season - 9"},
     "teams": {"home": {"id": 35}, "away": {"id": 34}}},
    {"fixture": {"id": 7, "date": "2026-10-24T14:00:00+00:00", "status": {"short": "NS"}}, "league": {"round": "Cup Replay"},
     "teams": {"home": {"id": 35}, "away": {"id": 33}}}]}


def test_fixtures_difficulty_from_standings_and_team_stats_share_one_call():
    a, b, http = make({"standings": STANDINGS, "fixtures": FIXTURES})
    fx = a.fetch_fixtures()
    ts = a.fetch_team_stats()
    assert b.used == 2 and [c[0] for c in http.calls] == ["standings", "fixtures"]
    first = fx[0]                                                # home=34 (rank 2, strength .5) v away=33 (rank 1, strength 1)
    assert (first.gameweek, first.status, first.difficulty_home, first.difficulty_away) == (10, "scheduled", 0.9, 0.6)
    assert fx[1].status == "finished" and len(fx) == 2           # round without a number skipped, with a warning
    assert a.warnings and (ts[2].total_minutes_available, ts[2].total_goals, ts[2].matches_played) == (720, 5, 8)


def test_no_standings_means_no_difficulty_not_a_guess():
    a, _, _ = make({"standings": {"response": []}, "fixtures": FIXTURES})
    assert a.fetch_fixtures()[0].difficulty_home is None and a.fetch_team_stats() == []


def _stat_row(pid, minutes, goals, assists, lineups, apps_key="appearences"):
    return {"player": {"id": pid}, "statistics": [{"games": {"minutes": minutes, "lineups": lineups, apps_key: lineups + 1},
                                                    "goals": {"total": goals, "assists": assists}}]}


def test_player_stats_paginate_and_handle_nulls():
    p1 = {"paging": {"current": 1, "total": 2}, "response": [_stat_row(1, 600, 3, 1, 7)]}
    p2 = {"paging": {"current": 2, "total": 2}, "response": [{"player": {"id": 2}, "statistics": [{"games": {"minutes": None}, "goals": {"total": None, "assists": None}}]}]}
    a, b, http = make({"players": [p1, p2]})
    st = a.fetch_player_stats()
    assert b.used == 2 and [c[1]["page"] for c in http.calls] == [1, 2]
    assert (st[0].minutes, st[0].goals, st[0].assists, st[0].starts, st[0].appearances) == (600, 3, 1, 7, 8)
    assert (st[1].minutes, st[1].goals) == (0, 0)


def test_budget_exhaustion_returns_partial_results_not_an_error():
    pages = [{"paging": {"total": 5}, "response": [_stat_row(i, 90, 0, 0, 1)]} for i in range(1, 6)]
    a, b, _ = make({"players": pages}, limit=3)                  # normal ceiling = int(3 * .9) = 2 calls
    st = a.fetch_player_stats()
    assert len(st) == 2 and a.partial and b.used == 2
    with pytest.raises(BudgetExceeded):
        a._get("injuries")


def test_fast_mode_may_use_reserved_slice():
    a, b, _ = make({"injuries": {"response": []}}, limit=100, mode="fast")
    b.used = 95
    assert a.fetch_injuries() == [] and b.used == 96


def test_status_sync_is_not_counted():
    a, b, _ = make({"status": {"response": {"requests": {"current": 42, "limit_day": 100}}}})
    a.sync_usage()
    assert b.used == 42
