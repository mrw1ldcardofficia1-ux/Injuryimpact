import json
import shutil
from pathlib import Path

import pytest

from injuryimpact.adapters import AdapterError, MockAdapter
from injuryimpact.adapters.mock import DEFAULT_MOCK_DIR
from injuryimpact.types import InjuryStatus


def test_counts_and_types():
    m = MockAdapter()
    assert (len(m.fetch_clubs()), len(m.fetch_players()), len(m.fetch_fixtures())) == (8, 48, 56)
    inj = m.fetch_injuries()
    assert len(inj) == 11 and all(i.source_url.strip() and i.reported_at.tzinfo for i in inj)
    assert {i.status for i in inj} <= set(InjuryStatus)


def test_every_reference_resolves():
    m = MockAdapter()
    clubs = {c.provider_club_id for c in m.fetch_clubs()}
    players = {p.provider_player_id: p for p in m.fetch_players()}
    assert all(p.provider_club_id in clubs for p in players.values())
    assert all(i.provider_player_id in players for i in m.fetch_injuries())
    assert all(f.home_provider_club_id in clubs and f.away_provider_club_id in clubs for f in m.fetch_fixtures())


def test_stats_are_internally_consistent():
    m = MockAdapter()
    team = {t.provider_club_id: t for t in m.fetch_team_stats()}
    club_of = {p.provider_player_id: p.provider_club_id for p in m.fetch_players()}
    goals: dict[str, int] = {}
    for st in m.fetch_player_stats():
        t = team[club_of[st.provider_player_id]]
        assert 0 <= st.minutes <= t.total_minutes_available == t.matches_played * 90
        goals[t.provider_club_id] = goals.get(t.provider_club_id, 0) + st.goals
    assert all(goals[c] <= team[c].total_goals for c in goals)


def test_fixtures_are_a_double_round_robin():
    fx = MockAdapter().fetch_fixtures()
    pairs = {(f.home_provider_club_id, f.away_provider_club_id) for f in fx}
    assert len(pairs) == len(fx) == 8 * 7
    assert all(0 <= f.difficulty_home <= 1 and 0 <= f.difficulty_away <= 1 for f in fx)


def test_missing_and_malformed_files_raise_adapter_error(tmp_path):
    with pytest.raises(AdapterError):
        MockAdapter(tmp_path).fetch_clubs()
    d = tmp_path / "bad"
    shutil.copytree(DEFAULT_MOCK_DIR, d)
    (d / "clubs.json").write_text(json.dumps([{"id": "c1"}]))      # missing name
    with pytest.raises(AdapterError):
        MockAdapter(d).fetch_clubs()
