from datetime import datetime, timedelta, timezone

import pytest

from injuryimpact.config import load_settings
from injuryimpact.impact import FixtureView, ScoringInput, club_score, fixture_difficulty, injury_score

S = load_settings()
NOW = datetime(2026, 10, 22, tzinfo=timezone.utc)


def _inp(**kw):
    base = dict(injury_id=1, player_minutes=2000, player_goals=8, player_assists=4,
                team_minutes_available=2700, team_goals=20, replacement_gap=0.9,
                fixtures=[FixtureView(NOW + timedelta(days=3), True, 0.8, 0.3)], as_of=NOW)
    base.update(kw)
    return ScoringInput(**base)


def test_known_score_and_audit_components():
    r = injury_score(_inp(), S.impact)
    assert r.score == 7.36
    c = r.components
    assert c.minutes_share == pytest.approx(0.7407, abs=1e-4) and c.goal_contribution_share == 0.6
    assert c.fixtures_in_window == 1 and not c.replacement_gap_defaulted and not c.fixture_window_empty
    assert sum(c.weights.values()) == pytest.approx(1.0)


def test_defaults_are_flagged():
    r = injury_score(_inp(replacement_gap=None, fixtures=[]), S.impact)
    assert r.components.replacement_gap == 0.5 and r.components.replacement_gap_defaulted
    assert r.components.fixture_difficulty == 0.5 and r.components.fixture_window_empty


def test_zero_denominators_do_not_crash():
    r = injury_score(_inp(team_minutes_available=0, team_goals=0), S.impact)
    assert r.components.minutes_share == 0 and r.components.goal_contribution_share == 0


def test_clamped_to_scale():
    r = injury_score(_inp(player_minutes=9999, player_goals=99, replacement_gap=1.0,
                          fixtures=[FixtureView(NOW + timedelta(days=1), False, 0, 1.0)]), S.impact)
    assert r.score == 10.0


def test_away_side_uses_away_difficulty():
    f = [FixtureView(NOW + timedelta(days=1), False, 0.9, 0.2)]
    assert fixture_difficulty(f, NOW, 28, 0.5) == (0.2, 1)


def test_window_edges_and_missing_difficulty():
    f = [FixtureView(NOW - timedelta(days=1), True, 1, 1),           # past
         FixtureView(NOW + timedelta(days=29), True, 1, 1),          # beyond window
         FixtureView(NOW + timedelta(days=2), True, None, None)]     # no rating
    assert fixture_difficulty(f, NOW, 28, 0.5) == (0.5, 0)


def test_club_diminishing_returns():
    five_minor = club_score(1, [(i, "out", 2.0) for i in range(5)], S.club, 10).score
    one_star = club_score(1, [(1, "out", 8.0)], S.club, 10).score
    assert five_minor < one_star == 8.0


def test_club_status_weights_and_empty():
    assert club_score(1, [(1, "doubtful", 8.0)], S.club, 10).score == 4.0
    assert club_score(1, [(1, "returning", 8.0)], S.club, 10).score == 2.0
    assert club_score(1, [], S.club, 10).score == 0.0


def test_club_never_exceeds_cap():
    assert club_score(1, [(i, "out", 10.0) for i in range(4)], S.club, 10).score == 10.0


def test_remaining_window():
    from datetime import date
    from injuryimpact.impact import remaining_window_days
    today = date(2026, 10, 22)
    assert remaining_window_days(None, None, today) == 28                    # unknown type
    assert remaining_window_days(3, None, today) == 21                       # no start date
    assert remaining_window_days(3, date(2026, 10, 15), today) == 14         # 7 days elapsed
    assert remaining_window_days(3, date(2026, 8, 1), today) == 7            # overdue -> minimum
