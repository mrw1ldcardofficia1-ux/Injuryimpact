from datetime import datetime, timedelta, timezone

from injuryimpact.budget import Budget
from injuryimpact.config import load_settings
from injuryimpact.planning import choose_mode, due_tasks

S = load_settings()
MON = datetime(2026, 10, 19, 12, tzinfo=timezone.utc)      # Monday
FRI = datetime(2026, 10, 23, 12, tzinfo=timezone.utc)      # Friday (press conference day)


def test_budget_stop_fractions():
    b = Budget(100, 0.90, 0.98)
    assert b.ceiling("normal") == 90 and b.ceiling("fast") == 98
    b.used = 89
    assert b.can_call("normal")
    b.record()
    assert not b.can_call("normal") and b.can_call("fast")
    b.used = 98
    assert not b.can_call("fast")


def test_choose_mode():
    assert choose_mode(MON, False, S) == "normal"
    assert choose_mode(MON, True, S) == "fast"              # matchday
    assert choose_mode(FRI, False, S) == "fast"             # press conferences


def test_first_run_does_everything_in_dependency_order():
    assert due_tasks("normal", {}, False, MON) == ["squads", "injuries", "fixtures", "stats"]


def test_up_to_date_run_only_polls_injuries():
    done = {"squads": MON - timedelta(days=2), "fixtures": MON - timedelta(hours=3), "stats": MON - timedelta(hours=3)}
    assert due_tasks("normal", done, True, MON) == ["injuries"]


def test_tasks_come_due_again():
    done = {"squads": MON - timedelta(days=8), "fixtures": MON - timedelta(hours=21), "stats": MON - timedelta(hours=19)}
    assert due_tasks("normal", done, True, MON) == ["squads", "injuries", "fixtures"]


def test_fast_mode_is_injuries_only():
    assert due_tasks("fast", {}, False, MON) == ["injuries"]
