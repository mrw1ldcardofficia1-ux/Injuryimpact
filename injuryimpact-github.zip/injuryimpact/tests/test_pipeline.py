"""DB-backed tests (need SQLAlchemy; they use the `session` fixture from conftest.py)."""
from datetime import datetime, timezone

from sqlalchemy import func, select

from injuryimpact.adapters import MockAdapter
from injuryimpact.config import load_settings
from injuryimpact.models import ClubImpactScore, Fixture, ImpactScore, Injury, Player
from injuryimpact.pipeline import ingest_injuries, run_scoring, seed_recovery_ranges, sync_reference_data
from injuryimpact.recovery import load_recovery_ranges

AS_OF = datetime(2026, 10, 22, 12, 0, tzinfo=timezone.utc)
S, RANGES = load_settings(), load_recovery_ranges()


def _loaded(session, adapter=None):
    adapter = adapter or MockAdapter()
    seed_recovery_ranges(session, RANGES)
    sync_reference_data(session, adapter)
    ingest_injuries(session, adapter, S, AS_OF)
    return adapter


def _count(session, model):
    return session.scalar(select(func.count()).select_from(model))


def test_reference_sync_is_idempotent(session):
    a = MockAdapter()
    first = sync_reference_data(session, a)
    second = sync_reference_data(session, a)
    assert (first["clubs"], first["players"], first["fixtures"]) == (8, 48, 56)
    assert (second["clubs"], second["players"], second["fixtures"]) == (0, 0, 0)
    assert _count(session, Player) == 48 and _count(session, Fixture) == 56


def test_latest_report_wins_and_problems_are_flagged(session):
    _loaded(session)
    injuries = session.scalars(select(Injury)).all()
    assert len(injuries) == 10                                   # 11 reports, one player reported twice
    flagged = {i.injury_type_raw: i.review_reason for i in injuries if i.needs_review}
    assert flagged == {"mystery knock": "unrecognised injury type",
                       "Calf strain": "start date in the future",
                       "stomach bug": "no start date",
                       "Groin injury": "stale report"}
    twice = next(i for i in injuries if i.injury_type_raw == "Muscle injury")
    assert twice.status == "out" and twice.injury_type == "muscle strain"


def test_injury_ingest_is_idempotent_and_deactivates_recovered(session):
    a = _loaded(session)
    again = ingest_injuries(session, a, S, AS_OF)
    assert again["created"] == 0 and again["updated"] == 10

    class Recovered(MockAdapter):                                # feed where all but one player recovered
        def fetch_injuries(self):
            return super().fetch_injuries()[:1]
    out = ingest_injuries(session, Recovered(), S, AS_OF)
    assert out["deactivated"] == 9
    assert len(session.scalars(select(Injury).where(Injury.is_active)).all()) == 1

    class Empty(MockAdapter):                                    # empty feed must NOT wipe everything
        def fetch_injuries(self):
            return []
    assert ingest_injuries(session, Empty(), S, AS_OF)["empty_feed_skipped"] == 1
    assert len(session.scalars(select(Injury).where(Injury.is_active)).all()) == 1


def test_scoring_writes_history_and_estimates(session):
    _loaded(session)
    out = run_scoring(session, S, RANGES, AS_OF)
    assert out["injuries_scored"] == 10 and len(out["club_scores"]) == 8
    scores = session.scalars(select(ImpactScore)).all()
    assert all(0 <= s.score <= 10 and s.weights_version.startswith("v1.0+") for s in scores)
    known = session.scalar(select(Injury).where(Injury.injury_type == "hamstring"))
    unknown = session.scalar(select(Injury).where(Injury.injury_type.is_(None)))
    assert known.expected_return_min_weeks is not None and known.return_is_estimate
    assert unknown.expected_return_min_weeks is None             # no guess for unrecognised types
    run_scoring(session, S, RANGES, AS_OF)                       # re-run appends history
    assert _count(session, ImpactScore) == 20 and _count(session, ClubImpactScore) == 16
