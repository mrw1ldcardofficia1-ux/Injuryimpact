"""Fails if migrations/001_initial.sql and models.py disagree on tables or columns."""
import re
from pathlib import Path

from injuryimpact.models import Base

SQL = (Path(__file__).resolve().parents[1] / "migrations" / "001_initial.sql").read_text()
SKIP = {"PRIMARY", "UNIQUE", "CHECK", "CONSTRAINT", "FOREIGN"}


def _parse_sql() -> dict[str, set[str]]:
    tables: dict[str, set[str]] = {}
    for m in re.finditer(r"CREATE TABLE (\w+) \((.*?)\n\);", SQL, re.S):
        cols = set()
        for line in m.group(2).splitlines():
            token = line.strip().split(" ")[0]
            if token and token.upper() not in SKIP:
                cols.add(token)
        tables[m.group(1)] = cols
    return tables


def test_tables_match():
    assert set(_parse_sql()) == set(Base.metadata.tables)


def test_columns_match():
    sql = _parse_sql()
    for name, table in Base.metadata.tables.items():
        assert sql[name] == {c.name for c in table.columns}, f"column drift in {name}"
