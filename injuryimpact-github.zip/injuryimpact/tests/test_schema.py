from datetime import datetime, timezone

import pytest
from sqlalchemy.exc import IntegrityError

from injuryimpact.models import Base, Club, Injury, Player

NOW = datetime(2026, 10, 22, 12, 0, tzinfo=timezone.utc)

EXPECTED_TABLES = {
    "clubs", "players", "injuries", "player_season_stats", "team_season_stats", "fixtures",
    "recovery_ranges", "impact_scores", "with_without_results", "raw_source_payloads",
    "change_log", "api_usage",
    # additions beyond the brief
    "external_ids", "injury_observations", "club_impact_scores", "pipeline_runs",
}


def _player(session):
    club = Club(name="Arsenal", short_name="ARS")
    session.add(club)
    session.flush()
    player = Player(club_id=club.id, name="Test Player", position="MID")
    session.add(player)
    session.flush()
    return player


def _injury(player, **kw):
    base = dict(player_id=player.id, injury_type="hamstring", injury_type_raw="hamstring strain",
                status="out", source_url="https://example.test/1", source_name="mock", reported_at=NOW)
    base.update(kw)
    return Injury(**base)


def test_all_tables_exist():
    assert set(Base.metadata.tables) == EXPECTED_TABLES


def test_invalid_status_rejected(session):
    session.add(_injury(_player(session), status="broken"))
    with pytest.raises(IntegrityError):
        session.flush()


def test_missing_source_url_rejected(session):
    session.add(_injury(_player(session), source_url="  "))
    with pytest.raises(IntegrityError):
        session.flush()


def test_return_range_must_be_ordered(session):
    session.add(_injury(_player(session), expected_return_min_weeks=6, expected_return_max_weeks=2))
    with pytest.raises(IntegrityError):
        session.flush()


def test_one_active_injury_per_player(session):
    p = _player(session)
    session.add(_injury(p))
    session.flush()
    session.add(_injury(p))
    with pytest.raises(IntegrityError):
        session.flush()


def test_inactive_history_allowed(session):
    p = _player(session)
    session.add_all([_injury(p, is_active=False), _injury(p, is_active=False), _injury(p)])
    session.flush()


def test_foreign_keys_enforced(session):
    session.add(Player(club_id=9999, name="Ghost", position="GK"))
    with pytest.raises(IntegrityError):
        session.flush()


def test_replacement_gap_range(session):
    club = Club(name="Chelsea", short_name="CHE")
    session.add(club)
    session.flush()
    session.add(Player(club_id=club.id, name="X", position="DEF", replacement_gap=1.5))
    with pytest.raises(IntegrityError):
        session.flush()
