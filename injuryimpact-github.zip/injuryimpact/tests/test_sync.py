"""DB-backed (needs SQLAlchemy). Uses the mock adapter so no network or API key is involved."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from injuryimpact.adapters import MockAdapter
from injuryimpact.config import load_settings
from injuryimpact.db import make_session_factory, session_scope
from injuryimpact.models import ApiUsage, Injury, PipelineRun
from injuryimpact.recovery import load_recovery_ranges
from injuryimpact.sync import PROVIDER, run_sync

S, RANGES = load_settings(), load_recovery_ranges()
T0 = datetime(2026, 10, 20, 9, tzinfo=timezone.utc)      # a Tuesday


def test_first_run_does_all_tasks_then_only_injuries(engine):
    factory = make_session_factory(engine)
    make = lambda budget, mode: MockAdapter()            # noqa: E731
    first = run_sync(factory, make, S, RANGES, "normal", T0)
    assert first["status"] == "success" and first["completed"] == ["squads", "injuries", "fixtures", "stats"]
    second = run_sync(factory, make, S, RANGES, "normal", T0 + timedelta(hours=4))
    assert second["completed"] == ["injuries"]
    third = run_sync(factory, make, S, RANGES, "fast", T0 + timedelta(hours=5))
    assert third["completed"] == ["injuries"]
    with session_scope(factory) as s:
        runs = s.scalars(select(PipelineRun).order_by(PipelineRun.id)).all()
        assert [r.status for r in runs] == ["success"] * 3 and [r.mode for r in runs] == ["scheduled", "scheduled", "matchday"]
        assert s.get(ApiUsage, (PROVIDER, T0.date())).calls_made == 0      # mock adapter spends no API calls
        assert s.scalar(select(Injury).where(Injury.needs_review.is_(False))) is not None


def test_failure_is_recorded_not_lost(engine):
    class Broken(MockAdapter):
        def fetch_injuries(self):
            raise RuntimeError("boom")
    factory = make_session_factory(engine)
    out = run_sync(factory, lambda b, m: Broken(), S, RANGES, "fast", T0)
    assert out["status"] == "failed" and "boom" in out["error"]
    with session_scope(factory) as s:
        run = s.scalars(select(PipelineRun)).one()
        assert run.status == "failed" and "boom" in run.error
