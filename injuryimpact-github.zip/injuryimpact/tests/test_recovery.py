from datetime import date

from injuryimpact.config import load_settings
from injuryimpact.recovery import BaseRange, age_on, estimate_recovery

CFG = load_settings().recovery
BASE = BaseRange("hamstring", 2, 4, 8)
TODAY = date(2026, 10, 22)


def test_no_modifiers():
    e = estimate_recovery(BASE, CFG, date_of_birth=date(2000, 1, 1), as_of=TODAY)
    assert (e.min_weeks, e.median_weeks, e.max_weeks) == (2, 4, 8)
    assert e.modifiers_applied == () and e.is_estimate


def test_age_modifier_boundary():
    assert age_on(date(1996, 10, 23), TODAY) == 29      # 30th birthday is tomorrow
    assert age_on(date(1996, 10, 22), TODAY) == 30
    young = estimate_recovery(BASE, CFG, date_of_birth=date(1996, 10, 23), as_of=TODAY)
    old = estimate_recovery(BASE, CFG, date_of_birth=date(1996, 10, 22), as_of=TODAY)
    assert young.median_weeks == 4 and old.median_weeks == 4.6


def test_reinjury_window():
    inside = estimate_recovery(BASE, CFG, as_of=TODAY, prior_same_type_dates=[date(2025, 10, 22)])
    outside = estimate_recovery(BASE, CFG, as_of=TODAY, prior_same_type_dates=[date(2025, 10, 21)])
    assert inside.median_weeks == 5.0 and outside.median_weeks == 4


def test_modifiers_stack_and_order_kept():
    e = estimate_recovery(BASE, CFG, date_of_birth=date(1990, 1, 1), as_of=TODAY,
                          prior_same_type_dates=[date(2026, 5, 1)])
    assert e.median_weeks == round(4 * 1.15 * 1.25, 1)
    assert e.min_weeks <= e.median_weeks <= e.max_weeks and len(e.modifiers_applied) == 2


def test_missing_dob_skips_age():
    assert estimate_recovery(BASE, CFG, as_of=TODAY).modifiers_applied == ()
