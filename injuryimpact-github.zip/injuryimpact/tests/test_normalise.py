import pytest

from injuryimpact.config import load_aliases
from injuryimpact.normalise import build_alias_index, clean, normalise_injury_type


def test_clean():
    assert clean("  Hamstring   Tightness!! ") == "hamstring tightness"


def test_alias_and_canonical_match():
    idx = build_alias_index(load_aliases())
    assert normalise_injury_type("Hamstring tightness", idx) == "hamstring"
    assert normalise_injury_type("ACL", idx) == "acl"
    assert normalise_injury_type("sprained ankle", idx) == "ankle sprain"


def test_unknown_returns_none_never_guesses():
    idx = build_alias_index(load_aliases())
    assert normalise_injury_type("mystery knock", idx) is None
    assert normalise_injury_type("", idx) is None


def test_conflicting_alias_rejected():
    with pytest.raises(ValueError):
        build_alias_index({"a": ["shared"], "b": ["shared"]})
