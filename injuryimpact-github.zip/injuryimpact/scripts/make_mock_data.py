"""Regenerate data/mock/*.json deterministically. Fictional clubs and players only,
so no real person ever has a made-up injury attached. Run: python scripts/make_mock_data.py"""
import json, random
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "data" / "mock"
AS_OF = datetime(2026, 10, 22, 12, 0, tzinfo=timezone.utc)
SEASON = "2026-27"
rng = random.Random(2026)

CLUBS = [("Northgate United", "NGU", .85), ("Harbourside City", "HBC", .80), ("Ironvale Rovers", "IVR", .65),
         ("Kestrel Town", "KST", .55), ("Riverbend Athletic", "RBA", .50), ("Stonebridge FC", "STB", .40),
         ("Thornfield Wanderers", "TFW", .30), ("Westmere Albion", "WMA", .20)]
FIRST = ["Alder", "Bram", "Cai", "Dorian", "Emlyn", "Finn", "Gideon", "Hale", "Idris", "Jory", "Kit", "Lorcan"]
LAST = ["Voss", "Marlow", "Quill", "Ashby", "Penrose", "Rook", "Sable", "Thorne", "Underhill", "Vance", "Wren", "Yarrow"]
POS = ["GK", "DEF", "DEF", "MID", "MID", "FWD"]

clubs = [{"id": f"c{i+1}", "name": n, "short_name": s} for i, (n, s, _) in enumerate(CLUBS)]
names = [f"{f} {l}" for f in FIRST for l in LAST]; rng.shuffle(names)

players, pstats, tstats = [], [], []
for ci, (_, _, _) in enumerate(CLUBS):
    team_goals = rng.randint(9, 20)
    scorers = []
    for pi, pos in enumerate(POS):
        pid = f"p{ci*6+pi+1}"
        dob = date(rng.randint(1991, 2006), rng.randint(1, 12), rng.randint(1, 28))
        players.append({"id": pid, "club_id": f"c{ci+1}", "name": names.pop(), "position": pos, "date_of_birth": dob.isoformat()})
        mins = 810 if pos == "GK" else rng.choice([450, 585, 675, 765, 810])
        scorers.append((pid, pos, mins))
    left = team_goals
    for pid, pos, mins in scorers:
        w = {"FWD": 5, "MID": 3, "DEF": 1, "GK": 0}[pos]
        g = min(left, rng.randint(0, w * 2)); left -= g
        a = rng.randint(0, 4 if pos in ("MID", "FWD") else 1)
        pstats.append({"player_id": pid, "season": SEASON, "minutes": mins, "goals": g, "assists": a,
                       "starts": mins // 90, "appearances": mins // 90 + (1 if mins % 90 else 0)})
    tstats.append({"club_id": f"c{ci+1}", "season": SEASON, "total_minutes_available": 810,
                   "total_goals": team_goals - left if left else team_goals, "matches_played": 9})
# keep team goals >= sum of player goals
for t in tstats:
    cid = t["club_id"]; s = sum(p["goals"] for p in pstats if players[int(p["player_id"][1:]) - 1]["club_id"] == cid)
    t["total_goals"] = max(t["total_goals"], s)

# double round robin (circle method), weekly from 2026-08-22
ids = list(range(8)); rounds = []
for r in range(7):
    rounds.append([(ids[i], ids[7 - i]) if (i + r) % 2 == 0 else (ids[7 - i], ids[i]) for i in range(4)])
    ids = [ids[0]] + [ids[-1]] + ids[1:-1]
rounds += [[(a, h) for h, a in rd] for rd in rounds]
fixtures, n = [], 1
for gw, rd in enumerate(rounds, 1):
    ko = datetime(2026, 8, 22, 15, 0, tzinfo=timezone.utc) + timedelta(days=7 * (gw - 1))
    for h, a in rd:
        fixtures.append({"id": f"f{n}", "season": SEASON, "gameweek": gw, "home_club_id": f"c{h+1}", "away_club_id": f"c{a+1}",
                         "kickoff": ko.isoformat(), "difficulty_home": round(max(0, CLUBS[a][2] - .1), 2),
                         "difficulty_away": round(min(1, CLUBS[h][2] + .1), 2),
                         "status": "finished" if ko < AS_OF else "scheduled"}); n += 1

def P(club, pos_idx): return f"p{(club-1)*6+pos_idx+1}"   # club 1-based, pos_idx 0..5
def inj(pid, raw, status, start, reported_days_ago):
    k = len(INJ) + 1
    INJ.append({"player_id": pid, "club_id": players[int(pid[1:]) - 1]["club_id"], "player_name": players[int(pid[1:]) - 1]["name"],
                "injury_type_raw": raw, "status": status, "start_date": start,
                "reported_at": (AS_OF - timedelta(days=reported_days_ago)).isoformat(),
                "source_name": "mock", "source_url": f"https://example.test/mock/injury/{k}"})
INJ = []
inj(P(1, 5), "Hamstring tightness", "out", "2026-10-15", 3)        # star forward, top club
inj(P(1, 3), "Sprained ankle", "doubtful", "2026-10-20", 1)
inj(P(2, 5), "ACL tear", "out", "2026-08-30", 12)                  # long-term
inj(P(2, 4), "mystery knock", "doubtful", "2026-10-21", 1)         # unknown -> needs review
inj(P(3, 3), "Concussion protocols", "returning", "2026-10-18", 2)
inj(P(3, 1), "Calf strain", "out", "2026-10-30", 0)                # start date in the future -> validation
inj(P(4, 2), "broken leg", "out", "2026-09-20", 4)
inj(P(5, 4), "stomach bug", "doubtful", None, 0)                   # no start date
inj(P(6, 3), "Groin injury", "out", "2026-09-01", 40)              # stale report (> 21 days)
inj(P(7, 5), "Muscle fatigue", "returning", "2026-10-10", 5)
inj(P(7, 5), "Muscle injury", "out", "2026-10-10", 2)              # newer report, same player (reconciliation)

OUT.mkdir(parents=True, exist_ok=True)
for name, data in [("clubs", clubs), ("players", players), ("fixtures", fixtures), ("injuries", INJ),
                   ("player_stats", pstats), ("team_stats", tstats)]:
    (OUT / f"{name}.json").write_text(json.dumps(data, indent=1) + "\n")
print({k: len(v) for k, v in [("clubs", clubs), ("players", players), ("fixtures", fixtures), ("injuries", INJ)]})
