"""Recovery-time estimates: a base range per injury type plus two modifiers.

Pure functions, no database. Output is always an estimate, never a prediction.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Iterable, Optional

from .config import RecoveryConfig
from .types import RecoveryEstimate


@dataclass(frozen=True)
class BaseRange:
    injury_type: str
    min_weeks: float
    median_weeks: float
    max_weeks: float


def age_on(dob: date, as_of: date) -> int:
    return as_of.year - dob.year - ((as_of.month, as_of.day) < (dob.month, dob.day))


def is_reinjury(prior_dates: Iterable[date], as_of: date, window_days: int) -> bool:
    """True if the same injury type was recorded within the window before as_of."""
    return any(0 <= (as_of - d).days <= window_days for d in prior_dates)


def estimate_recovery(
    base: BaseRange,
    cfg: RecoveryConfig,
    *,
    date_of_birth: Optional[date] = None,
    as_of: date,
    prior_same_type_dates: Iterable[date] = (),
) -> RecoveryEstimate:
    factor = 1.0
    applied: list[str] = []
    if date_of_birth is not None and age_on(date_of_birth, as_of) >= cfg.age_threshold:
        factor *= cfg.age_multiplier
        applied.append(f"age>={cfg.age_threshold} x{cfg.age_multiplier}")
    if is_reinjury(prior_same_type_dates, as_of, cfg.reinjury_window_days):
        factor *= cfg.reinjury_multiplier
        applied.append(f"reinjury<={cfg.reinjury_window_days}d x{cfg.reinjury_multiplier}")
    r = lambda w: round(w * factor, 1)  # noqa: E731
    return RecoveryEstimate(base.injury_type, r(base.min_weeks), r(base.median_weeks),
                            r(base.max_weeks), tuple(applied))


def load_recovery_ranges(config_dir=None) -> dict[str, "RangeRow"]:
    """Read config/recovery_ranges.yaml. Rows are validated (0 <= min <= median <= max)."""
    import os
    from pathlib import Path

    import yaml

    from .config import DEFAULT_CONFIG_DIR, ConfigError

    base = Path(config_dir or os.environ.get("INJURYIMPACT_CONFIG_DIR") or DEFAULT_CONFIG_DIR)
    data = yaml.safe_load((base / "recovery_ranges.yaml").read_text())
    out: dict[str, RangeRow] = {}
    for name, r in data.items():
        lo, med, hi, risk = float(r["min"]), float(r["median"]), float(r["max"]), float(r["reinjury_risk"])
        if not (0 <= lo <= med <= hi) or not (0 <= risk <= 1):
            raise ConfigError(f"recovery_ranges.{name}: need 0 <= min <= median <= max and 0 <= reinjury_risk <= 1.")
        out[str(name)] = RangeRow(BaseRange(str(name), lo, med, hi), risk, str(r.get("source_note", "")))
    return out


@dataclass(frozen=True)
class RangeRow:
    base: BaseRange
    reinjury_risk: float
    source_note: str
