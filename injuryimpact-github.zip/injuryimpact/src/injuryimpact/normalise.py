"""Map raw injury text from any source onto the canonical injury types.

Matching is exact (after cleaning) against config/injury_aliases.yaml. Anything
that matches nothing returns None so the pipeline can flag it for review.
We never guess.
"""
from __future__ import annotations

import re
from typing import Optional

_NON_WORD = re.compile(r"[^a-z0-9]+")


def clean(raw: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace."""
    return _NON_WORD.sub(" ", (raw or "").lower()).strip()


def build_alias_index(aliases: dict[str, list[str]]) -> dict[str, str]:
    """alias -> canonical. The canonical name itself is always an alias.

    Raises ValueError if one alias maps to two different canonical types.
    """
    index: dict[str, str] = {}
    for canonical, names in aliases.items():
        for name in [canonical, *names]:
            key = clean(name)
            if not key:
                continue
            if index.get(key, canonical) != canonical:
                raise ValueError(f"Alias {key!r} maps to both {index[key]!r} and {canonical!r}.")
            index[key] = canonical
    return index


def normalise_injury_type(raw: str, index: dict[str, str]) -> Optional[str]:
    return index.get(clean(raw))
