"""Impact Score engine. Pure functions: plain inputs in, auditable results out.

Injury score (0-10) = scale_max * sum(weight_i * component_i), each component in 0-1:
  minutes_share            player minutes / (matches_played * 90)
  goal_contribution_share  (goals + assists) / team goals, clamped to 1
  replacement_gap          manual 0-1 rating, config default if unrated
  fixture_difficulty       mean difficulty of the club's fixtures in the window
Club score combines injuries with diminishing returns (see club_score).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional, Sequence

from .config import ClubScoreConfig, ImpactConfig
from .types import ClubImpactResult, ImpactComponents, ImpactResult

DEFAULT_WINDOW_DAYS = 28


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def remaining_window_days(median_weeks: Optional[float], start_date: Optional[date], as_of_date: date,
                          minimum: float = 7.0, default: float = DEFAULT_WINDOW_DAYS) -> float:
    """Days of expected absence still ahead: start + median recovery - today, never below `minimum`.

    Unknown recovery (unrecognised injury type) falls back to `default`.
    """
    if median_weeks is None:
        return default
    elapsed = (as_of_date - start_date).days if start_date else 0
    return max(minimum, median_weeks * 7 - max(0, elapsed))


@dataclass(frozen=True)
class FixtureView:
    """A fixture seen from one club's side."""
    kickoff: datetime
    is_home: bool
    difficulty_home: Optional[float]
    difficulty_away: Optional[float]

    @property
    def difficulty(self) -> Optional[float]:
        return self.difficulty_home if self.is_home else self.difficulty_away


@dataclass(frozen=True)
class ScoringInput:
    injury_id: int
    player_minutes: int
    player_goals: int
    player_assists: int
    team_minutes_available: int
    team_goals: int
    replacement_gap: Optional[float]
    fixtures: Sequence[FixtureView]       # the club's upcoming fixtures
    as_of: datetime
    window_days: float = DEFAULT_WINDOW_DAYS


def fixture_difficulty(fixtures: Sequence[FixtureView], as_of: datetime, window_days: float,
                       neutral: float) -> tuple[float, int]:
    """Mean difficulty over fixtures in [as_of, as_of + window]. Returns (value, n_used)."""
    end = as_of + timedelta(days=window_days)
    vals = [f.difficulty for f in fixtures if as_of <= f.kickoff <= end and f.difficulty is not None]
    return (sum(vals) / len(vals), len(vals)) if vals else (neutral, 0)


def injury_score(inp: ScoringInput, cfg: ImpactConfig) -> ImpactResult:
    minutes = _clamp01(inp.player_minutes / inp.team_minutes_available) if inp.team_minutes_available > 0 else 0.0
    goals = _clamp01((inp.player_goals + inp.player_assists) / inp.team_goals) if inp.team_goals > 0 else 0.0
    defaulted = inp.replacement_gap is None
    gap = cfg.default_replacement_gap if defaulted else _clamp01(inp.replacement_gap)
    diff, n = fixture_difficulty(inp.fixtures, inp.as_of, inp.window_days, cfg.neutral_fixture_difficulty)

    w = cfg.weights
    raw = (w["minutes_share"] * minutes + w["goal_contribution_share"] * goals
           + w["replacement_gap"] * gap + w["fixture_difficulty"] * diff)
    comps = ImpactComponents(
        minutes_share=round(minutes, 4), goal_contribution_share=round(goals, 4),
        replacement_gap=round(gap, 4), fixture_difficulty=round(diff, 4),
        weights=dict(w), raw_score=round(raw, 4), scale_max=cfg.scale_max,
        replacement_gap_defaulted=defaulted, fixture_window_empty=(n == 0), fixtures_in_window=n)
    score = round(max(0.0, min(cfg.scale_max, raw * cfg.scale_max)), 2)
    return ImpactResult(inp.injury_id, score, comps, "")  # weights_version stamped by caller


def club_score(club_id: int, injuries: Sequence[tuple[int, str, float]], cfg: ClubScoreConfig,
               scale_max: float, weights_version: str = "") -> ClubImpactResult:
    """injuries: (injury_id, status, injury_score). score = scale_max * (1 - prod(1 - s*w/scale_max))."""
    if cfg.method != "diminishing_returns":
        raise ValueError(f"Unsupported club method {cfg.method!r}.")
    survive, contribs = 1.0, []
    for injury_id, status, s in injuries:
        sw = cfg.status_weights[status]
        eff = s * sw
        survive *= 1.0 - _clamp01(eff / scale_max)
        contribs.append({"injury_id": injury_id, "status": status, "score": s,
                         "status_weight": sw, "effective": round(eff, 4)})
    score = round(min(cfg.cap, scale_max * (1.0 - survive)), 2)
    return ClubImpactResult(club_id, score, tuple(contribs), weights_version, cfg.method)
