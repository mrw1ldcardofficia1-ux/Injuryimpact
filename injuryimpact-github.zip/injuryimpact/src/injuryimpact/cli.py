"""python -m injuryimpact.cli <demo | export | sync [--fast] | snapshot | check-api>
demo/export use the fictional mock feed. sync/snapshot/check-api use live API-Football data."""
from __future__ import annotations

import sys
from datetime import datetime, timezone

from sqlalchemy import select

from .adapters import MockAdapter
from .config import load_settings
from .db import init_db, make_engine, make_session_factory, session_scope
from .models import Club, ImpactScore, Injury, Player
from .pipeline import ingest_injuries, run_scoring, seed_recovery_ranges, sync_reference_data
from .recovery import load_recovery_ranges
from .types import MEDICAL_DISCLAIMER

AS_OF = datetime(2026, 10, 22, 12, 0, tzinfo=timezone.utc)   # matches the mock data's "today"


def demo() -> None:
    settings, ranges, adapter = load_settings(), load_recovery_ranges(), MockAdapter()
    engine = make_engine("sqlite://")
    init_db(engine)
    with session_scope(make_session_factory(engine)) as s:
        seed_recovery_ranges(s, ranges)
        print("reference:", sync_reference_data(s, adapter))
        print("injuries:", ingest_injuries(s, adapter, settings, AS_OF))
        out = run_scoring(s, settings, ranges, AS_OF)
        print("\nInjury scores (0-10)")
        rows = s.execute(select(ImpactScore.score, Player.name, Club.short_name, Injury.injury_type_raw, Injury.status,
                                Injury.needs_review, Injury.review_reason)
                         .join(Injury, Injury.id == ImpactScore.injury_id).join(Player, Player.id == Injury.player_id)
                         .join(Club, Club.id == Player.club_id).order_by(ImpactScore.score.desc())).all()
        for sc, name, club, raw, status, nr, why in rows:
            print(f"{sc:5.2f}  {club}  {name:<18} {raw:<22} {status:<9}{'  REVIEW: ' + why if nr else ''}")
        print("\nClub scores")
        for name, sc in sorted(out["club_scores"].items(), key=lambda kv: -kv[1]):
            print(f"{sc:5.2f}  {name}")
    print(f"\n{MEDICAL_DISCLAIMER}")


def export(path: str = "site/data/latest.json") -> None:
    """Run the pipeline on the mock feed and write the site's JSON. Swap MockAdapter for a real one in module 3."""
    from .export import build_snapshot, write_snapshot
    settings, ranges, adapter = load_settings(), load_recovery_ranges(), MockAdapter()
    engine = make_engine("sqlite://"); init_db(engine)
    with session_scope(make_session_factory(engine)) as s:
        seed_recovery_ranges(s, ranges); sync_reference_data(s, adapter)
        ingest_injuries(s, adapter, settings, AS_OF); run_scoring(s, settings, ranges, AS_OF)
        write_snapshot(build_snapshot(s, settings, AS_OF, is_demo=True), path)
    print(f"wrote {path}")


def _live_setup():
    from .config import load_dotenv_if_available
    load_dotenv_if_available()
    settings = load_settings()
    engine = make_engine(); init_db(engine)
    return settings, make_session_factory(engine)


def sync(fast: bool = False) -> None:
    """One live sync run against API-Football (needs API_FOOTBALL_KEY and DATABASE_URL)."""
    from .scheduler import build
    from .sync import run_sync
    settings, factory = _live_setup()
    out = run_sync(factory, build(settings), settings, load_recovery_ranges(), "fast" if fast else "normal", datetime.now(timezone.utc))
    print(out)
    if out["status"] == "failed":
        raise SystemExit(1)


def snapshot(path: str = "site/data/latest.json") -> None:
    """Write the website JSON from the live database."""
    from .export import build_snapshot, write_snapshot
    settings, factory = _live_setup()
    with session_scope(factory) as s:
        write_snapshot(build_snapshot(s, settings, datetime.now(timezone.utc)), path)
    print(f"wrote {path}")


def check_api() -> None:
    """Free check of key, plan and today's usage (/status is not counted), then ONE counted call to /injuries."""
    from .adapters import ApiFootballAdapter
    from .budget import Budget
    settings, _ = _live_setup()
    b = Budget(settings.providers["api_football"].daily_limit)
    a = ApiFootballAdapter(settings.providers["api_football"], settings.api_football_season, settings.season, b)
    a.sync_usage()
    print(f"calls used today: {b.used}/{b.limit}")
    print(f"injuries returned for season {settings.api_football_season}: {len(a.fetch_injuries())}; warnings: {a.warnings}")


COMMANDS = {"demo": demo, "export": export, "sync": sync, "snapshot": snapshot, "check-api": check_api}

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "sync":
        sync(fast="--fast" in sys.argv)
    else:
        COMMANDS.get(cmd, lambda: print(__doc__))()
