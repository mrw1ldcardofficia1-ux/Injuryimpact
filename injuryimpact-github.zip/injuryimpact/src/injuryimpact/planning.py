"""Pure scheduling decisions (no database): which mode, which tasks."""
from __future__ import annotations

from datetime import datetime, timedelta

from .config import Settings

TASK_PARTS = {"squads": frozenset({"clubs", "players"}), "fixtures": frozenset({"fixtures", "team_stats"}),
              "stats": frozenset({"player_stats"})}
TASK_EVERY = {"squads": timedelta(days=7), "fixtures": timedelta(hours=20), "stats": timedelta(hours=20)}


def choose_mode(now: datetime, matchday: bool, settings: Settings) -> str:
    """Fast mode on matchdays and press-conference weekdays, otherwise normal."""
    return "fast" if matchday or now.weekday() in settings.scheduler.press_conference_weekdays else "normal"


def due_tasks(mode: str, last_done: dict[str, datetime], have_players: bool, now: datetime) -> list[str]:
    """Tasks to run now, in order. `last_done` maps task -> last successful run time."""
    if mode == "fast":
        return ["injuries"]
    tasks = [t for t in ("squads",) if not have_players or _stale("squads", last_done, now)]
    tasks.append("injuries")
    tasks += [t for t in ("fixtures", "stats") if _stale(t, last_done, now)]
    return tasks


def _stale(task: str, last_done: dict[str, datetime], now: datetime) -> bool:
    return task not in last_done or now - last_done[task] >= TASK_EVERY[task]
