"""Long-running scheduler (needs an always-on host). On free hosting use the GitHub Actions cron instead."""
from __future__ import annotations

from datetime import datetime, timezone

from .adapters import ApiFootballAdapter
from .config import load_dotenv_if_available, load_settings
from .db import init_db, make_engine, make_session_factory, session_scope
from .recovery import load_recovery_ranges
from .sync import PROVIDER, choose_mode, is_matchday, run_sync


def build(settings):
    cfg = settings.providers[PROVIDER]
    return lambda budget, mode: ApiFootballAdapter(cfg, settings.api_football_season, settings.season, budget, mode=mode)


def tick(kind: str) -> None:
    """kind='normal' runs every normal_interval_hours; kind='fast' every fast_interval_minutes (does nothing off-matchday)."""
    settings, ranges = load_settings(), load_recovery_ranges()
    factory = make_session_factory(make_engine())
    now = datetime.now(timezone.utc)
    with session_scope(factory) as s:
        mode = choose_mode(now, is_matchday(s, now), settings)
    if kind == "fast" and mode != "fast":
        return
    print(run_sync(factory, build(settings), settings, ranges, kind, now))


def main() -> None:
    from apscheduler.schedulers.blocking import BlockingScheduler
    load_dotenv_if_available()
    settings = load_settings()
    init_db(make_engine())
    sch = BlockingScheduler(timezone="UTC")
    sch.add_job(tick, "interval", args=["normal"], hours=settings.scheduler.normal_interval_hours, next_run_time=datetime.now(timezone.utc))
    sch.add_job(tick, "interval", args=["fast"], minutes=settings.scheduler.fast_interval_minutes)
    sch.start()


if __name__ == "__main__":
    main()
