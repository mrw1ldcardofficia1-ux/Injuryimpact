"""Daily API call budget. Pure and unit-testable; persistence lives in sync.py."""
from __future__ import annotations

from dataclasses import dataclass


class BudgetExceeded(RuntimeError):
    """Raised when the next call would pass the stop fraction for the current mode."""


@dataclass
class Budget:
    limit: int
    normal_fraction: float = 0.90
    fast_fraction: float = 0.98
    used: int = 0

    def ceiling(self, mode: str = "normal") -> int:
        return int(self.limit * (self.fast_fraction if mode == "fast" else self.normal_fraction))

    def can_call(self, mode: str = "normal") -> bool:
        return self.used < self.ceiling(mode)

    def record(self, n: int = 1) -> None:
        self.used += n
