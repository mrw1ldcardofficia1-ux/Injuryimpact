"""Database glue: adapter output -> tables, then scoring -> impact tables.

All business logic lives in the pure modules (normalise, recovery, impact). This file
only moves data. Everything is idempotent: re-running ingest with the same feed changes nothing.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from .adapters.base import Adapter
from .config import Settings, load_aliases
from .impact import FixtureView, ScoringInput, club_score, injury_score, remaining_window_days
from .models import (ChangeLog, Club, ClubImpactScore, ExternalId, Fixture, ImpactScore, Injury,
                     InjuryObservation, Player, PlayerSeasonStats, RecoveryRange, TeamSeasonStats)
from .normalise import build_alias_index, normalise_injury_type
from .recovery import RangeRow, estimate_recovery


def _aware(dt: datetime) -> datetime:
    """SQLite returns naive datetimes. Everything in this project is UTC."""
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


# --------------------------------------------------------------------------- id mapping
def _lookup(s: Session, entity: str, provider: str, ext: str) -> Optional[int]:
    return s.scalar(select(ExternalId.internal_id).where(
        ExternalId.entity == entity, ExternalId.provider == provider, ExternalId.external_id == ext))


def _link(s: Session, entity: str, provider: str, ext: str, internal_id: int) -> None:
    s.add(ExternalId(entity=entity, provider=provider, external_id=ext, internal_id=internal_id))


# --------------------------------------------------------------------------- reference data
def seed_recovery_ranges(s: Session, ranges: dict[str, RangeRow]) -> None:
    for name, row in ranges.items():
        obj = s.get(RecoveryRange, name) or RecoveryRange(injury_type=name)
        obj.min_weeks, obj.median_weeks, obj.max_weeks = row.base.min_weeks, row.base.median_weeks, row.base.max_weeks
        obj.reinjury_risk, obj.source_note = row.reinjury_risk, row.source_note
        s.add(obj)
    s.flush()


ALL_PARTS = frozenset({"clubs", "players", "fixtures", "team_stats", "player_stats"})


def sync_reference_data(s: Session, adapter: Adapter, parts: frozenset[str] = ALL_PARTS) -> dict[str, int]:
    """Upsert the chosen parts only, so a run can spend API calls where they are due."""
    p, counts = adapter.name, {"clubs": 0, "players": 0, "fixtures": 0, "skipped": 0}
    for c in (adapter.fetch_clubs() if "clubs" in parts else []):
        if _lookup(s, "club", p, c.provider_club_id) is None:
            club = Club(name=c.name, short_name=c.short_name or c.name[:3].upper())
            s.add(club); s.flush()
            _link(s, "club", p, c.provider_club_id, club.id); counts["clubs"] += 1
    for pl in (adapter.fetch_players() if "players" in parts else []):
        club_id = _lookup(s, "club", p, pl.provider_club_id)
        if club_id is None:
            counts["skipped"] += 1; continue
        if pl.position is None:                      # position is required; never guess it
            counts["skipped"] += 1; continue
        pid = _lookup(s, "player", p, pl.provider_player_id)
        if pid is None:
            if s.scalar(select(Player.id).where(Player.club_id == club_id, Player.name == pl.name)) is not None:
                counts["skipped"] += 1; continue        # same name twice in one club (unique constraint)
            obj = Player(club_id=club_id, name=pl.name, position=pl.position.value,
                         date_of_birth=pl.date_of_birth)
            s.add(obj); s.flush()
            _link(s, "player", p, pl.provider_player_id, obj.id); counts["players"] += 1
    for f in (adapter.fetch_fixtures() if "fixtures" in parts else []):
        home, away = (_lookup(s, "club", p, f.home_provider_club_id), _lookup(s, "club", p, f.away_provider_club_id))
        if home is None or away is None:
            counts["skipped"] += 1; continue
        fid = _lookup(s, "fixture", p, f.provider_fixture_id)
        obj = s.get(Fixture, fid) if fid else None
        if obj is None:
            obj = Fixture(season=f.season, home_club_id=home, away_club_id=away, gameweek=f.gameweek, kickoff=f.kickoff)
            s.add(obj); s.flush()
            _link(s, "fixture", p, f.provider_fixture_id, obj.id); counts["fixtures"] += 1
        obj.gameweek, obj.kickoff, obj.status = f.gameweek, f.kickoff, f.status
        obj.difficulty_home, obj.difficulty_away = f.difficulty_home, f.difficulty_away
    for st in (adapter.fetch_player_stats() if "player_stats" in parts else []):
        pid = _lookup(s, "player", p, st.provider_player_id)
        if pid is None:
            counts["skipped"] += 1; continue
        obj = s.get(PlayerSeasonStats, (pid, st.season)) or PlayerSeasonStats(player_id=pid, season=st.season)
        obj.minutes, obj.goals, obj.assists, obj.starts, obj.appearances = st.minutes, st.goals, st.assists, st.starts, st.appearances
        s.add(obj)
    for st in (adapter.fetch_team_stats() if "team_stats" in parts else []):
        cid = _lookup(s, "club", p, st.provider_club_id)
        if cid is None:
            counts["skipped"] += 1; continue
        obj = s.get(TeamSeasonStats, (cid, st.season)) or TeamSeasonStats(club_id=cid, season=st.season)
        obj.total_minutes_available, obj.total_goals, obj.matches_played = st.total_minutes_available, st.total_goals, st.matches_played
        s.add(obj)
    s.flush()
    return counts


# --------------------------------------------------------------------------- injuries
def _review_reasons(injury_type: Optional[str], start: Optional[date], reported_at: datetime,
                    settings: Settings, as_of: datetime) -> list[str]:
    v, reasons = settings.validation, []
    if injury_type is None:
        reasons.append("unrecognised injury type")
    if start is None:
        reasons.append("no start date")
    elif start > as_of.date() + timedelta(days=v.max_future_start_days):
        reasons.append("start date in the future")
    if _aware(reported_at) < as_of - timedelta(days=v.stale_report_days):
        reasons.append("stale report")
    return reasons


def _log(s: Session, inj_id: int, field: str, old: Any, new: Any, source: str) -> None:
    if str(old) != str(new):
        s.add(ChangeLog(entity="injury", entity_id=inj_id, field=field, old_value=str(old), new_value=str(new), source_name=source))


def ingest_injuries(s: Session, adapter: Adapter, settings: Settings, as_of: datetime,
                    deactivate_missing: bool = True, first_seen_start: bool = False) -> dict[str, int]:
    """Latest report per player wins; every report is kept as an observation.

    Players who were active last run but are absent from a full feed are marked recovered (is_active=False).
    """
    index = build_alias_index(load_aliases())
    p, counts = adapter.name, {"created": 0, "updated": 0, "deactivated": 0, "needs_review": 0, "skipped": 0}
    latest: dict[int, Any] = {}
    for n in sorted(adapter.fetch_injuries(), key=lambda x: _aware(x.reported_at)):
        pid = _lookup(s, "player", p, n.provider_player_id)
        if pid is None:
            counts["skipped"] += 1; continue
        s.add(InjuryObservation(player_id=pid, source_name=n.source_name, source_url=n.source_url, status=n.status.value,
                                injury_type_raw=n.injury_type_raw, reported_at=n.reported_at))
        latest[pid] = n                                  # sorted ascending, so the last write is the newest
    for pid, n in latest.items():
        itype = normalise_injury_type(n.injury_type_raw, index)
        inj = s.scalar(select(Injury).where(Injury.player_id == pid, Injury.is_active.is_(True)))
        start = n.start_date
        if first_seen_start and start is None:          # source gives no start date: use the day we first saw it
            start = (inj.start_date if inj else None) or as_of.date()
        reasons = _review_reasons(itype, start, n.reported_at, settings, as_of)
        if inj is None:
            inj = Injury(player_id=pid, injury_type=itype, injury_type_raw=n.injury_type_raw, status=n.status.value,
                         start_date=start, source_url=n.source_url, source_name=n.source_name, reported_at=n.reported_at)
            s.add(inj); counts["created"] += 1
        else:
            _log(s, inj.id, "status", inj.status, n.status.value, p)
            _log(s, inj.id, "injury_type", inj.injury_type, itype, p)
            inj.injury_type, inj.injury_type_raw, inj.status = itype, n.injury_type_raw, n.status.value
            inj.start_date, inj.source_url, inj.source_name, inj.reported_at = start, n.source_url, n.source_name, n.reported_at
            counts["updated"] += 1
        inj.needs_review, inj.review_reason = bool(reasons), "; ".join(reasons) or None
        counts["needs_review"] += bool(reasons)
    s.flush()
    if deactivate_missing and not latest:
        counts["empty_feed_skipped"] = 1                # an empty feed usually means a bad league/season, not 'everyone recovered'
    elif deactivate_missing:
        for inj in s.scalars(select(Injury).where(Injury.is_active.is_(True), Injury.source_name == p)).all():
            if inj.player_id not in latest:
                inj.is_active = False
                _log(s, inj.id, "is_active", True, False, p); counts["deactivated"] += 1
        s.flush()
    return counts


# --------------------------------------------------------------------------- scoring
def run_scoring(s: Session, settings: Settings, ranges: dict[str, RangeRow], as_of: datetime) -> dict[str, Any]:
    season, version = settings.season, settings.weights_version
    by_club: dict[int, list[tuple[int, str, float]]] = {}
    for inj in s.scalars(select(Injury).where(Injury.is_active.is_(True))).all():
        player = s.get(Player, inj.player_id)
        ps = s.get(PlayerSeasonStats, (player.id, season))
        ts = s.get(TeamSeasonStats, (player.club_id, season))
        row = ranges.get(inj.injury_type) if inj.injury_type else None
        est = None
        if row is not None:
            prior = [i.start_date or _aware(i.reported_at).date() for i in s.scalars(select(Injury).where(
                Injury.player_id == player.id, Injury.injury_type == inj.injury_type, Injury.id != inj.id)).all()]
            est = estimate_recovery(row.base, settings.recovery, date_of_birth=player.date_of_birth,
                                    as_of=as_of.date(), prior_same_type_dates=prior)
            inj.expected_return_min_weeks, inj.expected_return_max_weeks, inj.return_is_estimate = est.min_weeks, est.max_weeks, True
        fixtures = [FixtureView(_aware(f.kickoff), f.home_club_id == player.club_id, f.difficulty_home, f.difficulty_away)
                    for f in s.scalars(select(Fixture).where(
                        Fixture.season == season, (Fixture.home_club_id == player.club_id) | (Fixture.away_club_id == player.club_id)))]
        res = injury_score(ScoringInput(
            injury_id=inj.id, player_minutes=ps.minutes if ps else 0, player_goals=ps.goals if ps else 0,
            player_assists=ps.assists if ps else 0, team_minutes_available=ts.total_minutes_available if ts else 0,
            team_goals=ts.total_goals if ts else 0, replacement_gap=player.replacement_gap, fixtures=fixtures, as_of=as_of,
            window_days=remaining_window_days(est.median_weeks if est else None, inj.start_date, as_of.date())), settings.impact)
        s.add(ImpactScore(injury_id=inj.id, score=res.score, components=res.components.to_dict(),
                          weights_version=version, calculated_at=as_of))
        by_club.setdefault(player.club_id, []).append((inj.id, inj.status, res.score))
    s.flush()
    clubs = {}
    for club in s.scalars(select(Club)).all():
        r = club_score(club.id, by_club.get(club.id, []), settings.club, settings.impact.scale_max, version)
        s.add(ClubImpactScore(club_id=club.id, score=r.score, weights_version=version, calculated_at=as_of,
                              components={"method": r.method, "contributions": list(r.contributions)}))
        clubs[club.name] = r.score
    s.flush()
    return {"injuries_scored": sum(map(len, by_club.values())), "club_scores": clubs}
