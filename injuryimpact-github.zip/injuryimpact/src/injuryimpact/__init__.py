"""InjuryImpact: Premier League injury data pipeline and Impact Score engine."""
__version__ = "0.1.0"
