"""Turn the latest scores into one JSON file the static site reads (no server needed)."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import Settings
from .models import Club, ClubImpactScore, ImpactScore, Injury, Player
from .types import MEDICAL_DISCLAIMER


def build_snapshot(s: Session, settings: Settings, as_of: datetime, is_demo: bool = False) -> dict[str, Any]:
    clubs, seen = [], set()
    q = (select(ClubImpactScore, Club.name, Club.short_name).join(Club, Club.id == ClubImpactScore.club_id)
         .order_by(ClubImpactScore.calculated_at.desc(), ClubImpactScore.id.desc()))
    for cs, name, short in s.execute(q).all():
        if cs.club_id not in seen:                      # newest row per club only
            seen.add(cs.club_id); clubs.append({"name": name, "short": short, "score": cs.score})
    clubs.sort(key=lambda c: -c["score"])
    injuries = []
    for inj, player, club in s.execute(select(Injury, Player, Club).join(Player, Player.id == Injury.player_id)
                                       .join(Club, Club.id == Player.club_id).where(Injury.is_active.is_(True))).all():
        sc = s.scalar(select(ImpactScore).where(ImpactScore.injury_id == inj.id)
                      .order_by(ImpactScore.calculated_at.desc(), ImpactScore.id.desc()).limit(1))
        if sc is None:
            continue
        injuries.append({"player": player.name, "club": club.name, "type": inj.injury_type, "raw": inj.injury_type_raw,
                         "status": inj.status, "score": sc.score, "min_weeks": inj.expected_return_min_weeks,
                         "max_weeks": inj.expected_return_max_weeks, "source_name": inj.source_name,
                         "source_url": inj.source_url, "needs_review": inj.needs_review, "review_reason": inj.review_reason})
    injuries.sort(key=lambda i: -i["score"])
    return {"generated_at": as_of.isoformat(), "season": settings.season, "weights_version": settings.weights_version,
            "disclaimer": MEDICAL_DISCLAIMER, "is_demo": is_demo, "clubs": clubs, "injuries": injuries}


def write_snapshot(snapshot: dict[str, Any], path: str | Path) -> None:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(snapshot, indent=1) + "\n")
