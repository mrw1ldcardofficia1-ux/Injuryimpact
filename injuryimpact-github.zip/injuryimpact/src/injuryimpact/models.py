"""SQLAlchemy 2.0 models. Single source of truth for the schema.

Works on SQLite (local dev) and PostgreSQL (JSON columns become JSONB).
migrations/001_initial.sql mirrors this file for Postgres/Supabase, and
tests/test_sql_parity.py fails if the two drift apart.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from sqlalchemy import (
    JSON, BigInteger, Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey,
    Index, Integer, MetaData, String, Text, UniqueConstraint, func, text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from .types import InjuryStatus, Position

NAMING = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING)


PK = BigInteger().with_variant(Integer(), "sqlite")     # SQLite only autoincrements INTEGER PKs
JsonType = JSON().with_variant(JSONB(), "postgresql")
TZ = DateTime(timezone=True)


def _in(column: str, values: list[str]) -> str:
    return f"{column} IN ({', '.join(repr(v) for v in values)})"


STATUSES = [s.value for s in InjuryStatus]
POSITIONS = [p.value for p in Position]


# ---------------------------------------------------------------------------
class Club(Base):
    __tablename__ = "clubs"

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text, unique=True)
    short_name: Mapped[str] = mapped_column(String(10), unique=True)

    players: Mapped[list["Player"]] = relationship(back_populates="club")


class Player(Base):
    __tablename__ = "players"
    __table_args__ = (
        UniqueConstraint("club_id", "name"),
        CheckConstraint(_in("position", POSITIONS), name="position_valid"),
        CheckConstraint("replacement_gap IS NULL OR (replacement_gap >= 0 AND replacement_gap <= 1)",
                        name="replacement_gap_range"),
        Index("ix_players_club_id", "club_id"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    club_id: Mapped[int] = mapped_column(ForeignKey("clubs.id"))
    name: Mapped[str] = mapped_column(Text)
    position: Mapped[str] = mapped_column(String(3))
    date_of_birth: Mapped[Optional[date]] = mapped_column(Date)            # for the age modifier
    is_key_player: Mapped[bool] = mapped_column(Boolean, default=False, server_default=text("false"))
    replacement_gap: Mapped[Optional[float]] = mapped_column(Float)        # manual 0-1 rating; NULL = unrated

    club: Mapped[Club] = relationship(back_populates="players")
    injuries: Mapped[list["Injury"]] = relationship(back_populates="player")


class ExternalId(Base):
    """Maps provider IDs to internal IDs so adapters stay provider-agnostic."""

    __tablename__ = "external_ids"
    __table_args__ = (
        UniqueConstraint("entity", "provider", "external_id"),
        CheckConstraint(_in("entity", ["club", "player", "fixture"]), name="entity_valid"),
        Index("ix_external_ids_entity_internal", "entity", "internal_id"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    entity: Mapped[str] = mapped_column(String(20))
    provider: Mapped[str] = mapped_column(String(40))
    external_id: Mapped[str] = mapped_column(String(80))
    internal_id: Mapped[int] = mapped_column(PK)


class RawSourcePayload(Base):
    """Raw API responses kept for audit and for cache-hit detection via payload_hash."""

    __tablename__ = "raw_source_payloads"
    __table_args__ = (
        Index("ix_raw_payloads_lookup", "source_name", "endpoint", "params_hash", "fetched_at"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    source_name: Mapped[str] = mapped_column(String(40))
    endpoint: Mapped[str] = mapped_column(Text)
    params_hash: Mapped[str] = mapped_column(String(64))
    fetched_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())
    payload_hash: Mapped[str] = mapped_column(String(64))
    payload: Mapped[Any] = mapped_column(JsonType)


class Injury(Base):
    __tablename__ = "injuries"
    __table_args__ = (
        CheckConstraint(_in("status", STATUSES), name="status_valid"),
        CheckConstraint("length(trim(source_name)) > 0", name="source_name_present"),
        CheckConstraint("length(trim(source_url)) > 0", name="source_url_present"),
        CheckConstraint(
            "expected_return_min_weeks IS NULL OR expected_return_max_weeks IS NULL "
            "OR (expected_return_min_weeks >= 0 AND expected_return_min_weeks <= expected_return_max_weeks)",
            name="return_range_valid"),
        Index("ix_injuries_player_id", "player_id"),
        Index("ix_injuries_status", "status"),
        # One active injury per player: also catches duplicate-player records.
        Index("uq_injuries_one_active_per_player", "player_id", unique=True,
              postgresql_where=text("is_active"), sqlite_where=text("is_active")),
        Index("ix_injuries_needs_review", "id",
              postgresql_where=text("needs_review"), sqlite_where=text("needs_review")),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"))
    injury_type: Mapped[Optional[str]] = mapped_column(Text)               # normalised; NULL = unknown, needs review
    injury_type_raw: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10))
    start_date: Mapped[Optional[date]] = mapped_column(Date)
    expected_return_min_weeks: Mapped[Optional[float]] = mapped_column(Float)
    expected_return_max_weeks: Mapped[Optional[float]] = mapped_column(Float)
    return_is_estimate: Mapped[bool] = mapped_column(Boolean, default=True, server_default=text("true"))
    source_url: Mapped[str] = mapped_column(Text)
    source_name: Mapped[str] = mapped_column(String(40))
    reported_at: Mapped[datetime] = mapped_column(TZ)
    created_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now(), onupdate=func.now())
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default=text("true"))
    needs_review: Mapped[bool] = mapped_column(Boolean, default=False, server_default=text("false"))
    review_reason: Mapped[Optional[str]] = mapped_column(Text)

    player: Mapped[Player] = relationship(back_populates="injuries")
    scores: Mapped[list["ImpactScore"]] = relationship(back_populates="injury", cascade="all, delete-orphan")


class InjuryObservation(Base):
    """What each source claimed and when. Powers reconciliation and weekly discrepancy rates."""

    __tablename__ = "injury_observations"
    __table_args__ = (
        CheckConstraint(_in("status", STATUSES), name="status_valid"),
        Index("ix_injury_obs_player_reported", "player_id", "reported_at"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"))
    injury_id: Mapped[Optional[int]] = mapped_column(ForeignKey("injuries.id", ondelete="SET NULL"))
    source_name: Mapped[str] = mapped_column(String(40))
    source_url: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(10))
    injury_type_raw: Mapped[Optional[str]] = mapped_column(Text)
    reported_at: Mapped[datetime] = mapped_column(TZ)
    payload_id: Mapped[Optional[int]] = mapped_column(ForeignKey("raw_source_payloads.id"))
    observed_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())


class PlayerSeasonStats(Base):
    __tablename__ = "player_season_stats"
    __table_args__ = (
        CheckConstraint("minutes >= 0 AND goals >= 0 AND assists >= 0 AND starts >= 0 AND appearances >= 0",
                        name="non_negative"),
    )

    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"), primary_key=True)
    season: Mapped[str] = mapped_column(String(7), primary_key=True)
    minutes: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    goals: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    assists: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    starts: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    appearances: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    updated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now(), onupdate=func.now())


class TeamSeasonStats(Base):
    __tablename__ = "team_season_stats"
    __table_args__ = (
        CheckConstraint("total_minutes_available >= 0 AND total_goals >= 0 AND matches_played >= 0",
                        name="non_negative"),
    )

    club_id: Mapped[int] = mapped_column(ForeignKey("clubs.id"), primary_key=True)
    season: Mapped[str] = mapped_column(String(7), primary_key=True)
    # matches_played * 90: the most minutes any single player could have played.
    total_minutes_available: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    total_goals: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    matches_played: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    updated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now(), onupdate=func.now())


class Fixture(Base):
    __tablename__ = "fixtures"
    __table_args__ = (
        UniqueConstraint("season", "home_club_id", "away_club_id"),
        CheckConstraint("home_club_id <> away_club_id", name="distinct_clubs"),
        CheckConstraint("difficulty_home IS NULL OR (difficulty_home >= 0 AND difficulty_home <= 1)",
                        name="difficulty_home_range"),
        CheckConstraint("difficulty_away IS NULL OR (difficulty_away >= 0 AND difficulty_away <= 1)",
                        name="difficulty_away_range"),
        Index("ix_fixtures_season_kickoff", "season", "kickoff"),
        Index("ix_fixtures_home_club", "home_club_id"),
        Index("ix_fixtures_away_club", "away_club_id"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    season: Mapped[str] = mapped_column(String(7))
    gameweek: Mapped[int] = mapped_column(Integer)
    home_club_id: Mapped[int] = mapped_column(ForeignKey("clubs.id"))
    away_club_id: Mapped[int] = mapped_column(ForeignKey("clubs.id"))
    kickoff: Mapped[datetime] = mapped_column(TZ)
    difficulty_home: Mapped[Optional[float]] = mapped_column(Float)   # how hard for the HOME side, 0-1
    difficulty_away: Mapped[Optional[float]] = mapped_column(Float)   # how hard for the AWAY side, 0-1
    status: Mapped[str] = mapped_column(String(12), default="scheduled", server_default=text("'scheduled'"))
    updated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now(), onupdate=func.now())


class RecoveryRange(Base):
    __tablename__ = "recovery_ranges"
    __table_args__ = (
        CheckConstraint("min_weeks >= 0 AND min_weeks <= median_weeks AND median_weeks <= max_weeks",
                        name="ordered"),
        CheckConstraint("reinjury_risk >= 0 AND reinjury_risk <= 1", name="reinjury_range"),
    )

    injury_type: Mapped[str] = mapped_column(Text, primary_key=True)
    min_weeks: Mapped[float] = mapped_column(Float)
    median_weeks: Mapped[float] = mapped_column(Float)
    max_weeks: Mapped[float] = mapped_column(Float)
    reinjury_risk: Mapped[float] = mapped_column(Float)
    source_note: Mapped[str] = mapped_column(Text)


class ImpactScore(Base):
    """One row per calculation (history kept). Latest = max(calculated_at)."""

    __tablename__ = "impact_scores"
    __table_args__ = (
        CheckConstraint("score >= 0 AND score <= 10", name="score_range"),
        Index("ix_impact_scores_injury", "injury_id", "calculated_at"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    injury_id: Mapped[int] = mapped_column(ForeignKey("injuries.id", ondelete="CASCADE"))
    score: Mapped[float] = mapped_column(Float)
    components: Mapped[Any] = mapped_column(JsonType)
    weights_version: Mapped[str] = mapped_column(String(40))
    calculated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())

    injury: Mapped[Injury] = relationship(back_populates="scores")


class ClubImpactScore(Base):
    __tablename__ = "club_impact_scores"
    __table_args__ = (
        CheckConstraint("score >= 0 AND score <= 10", name="score_range"),
        Index("ix_club_impact_scores_club", "club_id", "calculated_at"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    club_id: Mapped[int] = mapped_column(ForeignKey("clubs.id"))
    score: Mapped[float] = mapped_column(Float)
    components: Mapped[Any] = mapped_column(JsonType)
    weights_version: Mapped[str] = mapped_column(String(40))
    calculated_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())


class WithWithoutResult(Base):
    __tablename__ = "with_without_results"
    __table_args__ = (
        CheckConstraint("matches_with >= 0 AND matches_without >= 0 AND points_with >= 0 AND points_without >= 0",
                        name="non_negative"),
        CheckConstraint("points_with <= 3 * matches_with AND points_without <= 3 * matches_without",
                        name="points_possible"),
    )

    player_id: Mapped[int] = mapped_column(ForeignKey("players.id"), primary_key=True)
    season: Mapped[str] = mapped_column(String(7), primary_key=True)
    matches_with: Mapped[int] = mapped_column(Integer)
    points_with: Mapped[int] = mapped_column(Integer)
    matches_without: Mapped[int] = mapped_column(Integer)
    points_without: Mapped[int] = mapped_column(Integer)


class ChangeLog(Base):
    __tablename__ = "change_log"
    __table_args__ = (
        Index("ix_change_log_entity", "entity", "entity_id", "changed_at"),
        Index("ix_change_log_changed_at", "changed_at"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    entity: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[int] = mapped_column(PK)
    field: Mapped[str] = mapped_column(String(60))
    old_value: Mapped[Optional[str]] = mapped_column(Text)
    new_value: Mapped[Optional[str]] = mapped_column(Text)
    source_name: Mapped[Optional[str]] = mapped_column(String(40))
    changed_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())


class ApiUsage(Base):
    __tablename__ = "api_usage"
    __table_args__ = (
        CheckConstraint("calls_made >= 0 AND daily_limit > 0", name="counts_valid"),
    )

    provider: Mapped[str] = mapped_column(String(40), primary_key=True)
    usage_date: Mapped[date] = mapped_column("date", Date, primary_key=True)
    calls_made: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    daily_limit: Mapped[int] = mapped_column(Integer)


class PipelineRun(Base):
    __tablename__ = "pipeline_runs"
    __table_args__ = (
        CheckConstraint(_in("mode", ["scheduled", "matchday", "manual", "backfill"]), name="mode_valid"),
        CheckConstraint(_in("status", ["running", "success", "partial", "failed"]), name="status_valid"),
    )

    id: Mapped[int] = mapped_column(PK, primary_key=True, autoincrement=True)
    mode: Mapped[str] = mapped_column(String(20))
    started_at: Mapped[datetime] = mapped_column(TZ, server_default=func.now())
    finished_at: Mapped[Optional[datetime]] = mapped_column(TZ)
    status: Mapped[str] = mapped_column(String(12), default="running", server_default=text("'running'"))
    summary: Mapped[Optional[Any]] = mapped_column(JsonType)
    error: Mapped[Optional[str]] = mapped_column(Text)
