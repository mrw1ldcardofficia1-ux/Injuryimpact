"""Normalised data types shared by adapters, pipeline and scoring.

Every adapter outputs these dataclasses and nothing else, so sources can be
swapped without touching scoring code. Adapters never write to the database.

Conventions
-----------
* ``total_minutes_available`` (team) = matches_played * 90, i.e. the maximum
  minutes any single player could have played. That keeps
  ``minutes_share = player_minutes / total_minutes_available`` on a 0-1 scale.
* ``difficulty_home`` is how hard the fixture is for the HOME side (0 easy,
  1 hard); ``difficulty_away`` is the same for the away side.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Any, Optional

MEDICAL_DISCLAIMER = "Estimate only. Not medical advice; actual return dates may differ."


class InjuryStatus(str, Enum):
    OUT = "out"
    DOUBTFUL = "doubtful"
    RETURNING = "returning"


class Position(str, Enum):
    GK = "GK"
    DEF = "DEF"
    MID = "MID"
    FWD = "FWD"


# ---------------------------------------------------------------------------
# Adapter output (normalised format)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class NormClub:
    provider: str
    provider_club_id: str
    name: str
    short_name: Optional[str] = None


@dataclass(frozen=True)
class NormPlayer:
    provider: str
    provider_player_id: str
    provider_club_id: str
    name: str
    position: Optional[Position] = None
    date_of_birth: Optional[date] = None


@dataclass(frozen=True)
class NormInjury:
    provider: str
    provider_player_id: str
    provider_club_id: str
    player_name: str
    injury_type_raw: str
    status: InjuryStatus
    reported_at: datetime
    source_name: str
    source_url: str
    start_date: Optional[date] = None
    # Most APIs give no return date. If one is supplied (manual adapter) it is
    # kept as a note only; the pipeline still derives an estimate from recovery_ranges.
    source_return_note: Optional[str] = None
    payload_id: Optional[int] = None  # raw_source_payloads.id, set by the pipeline


@dataclass(frozen=True)
class NormFixture:
    provider: str
    provider_fixture_id: str
    season: str
    gameweek: int
    home_provider_club_id: str
    away_provider_club_id: str
    kickoff: datetime
    difficulty_home: Optional[float] = None
    difficulty_away: Optional[float] = None
    status: str = "scheduled"


@dataclass(frozen=True)
class NormPlayerStats:
    provider: str
    provider_player_id: str
    season: str
    minutes: int = 0
    goals: int = 0
    assists: int = 0
    starts: int = 0
    appearances: int = 0


@dataclass(frozen=True)
class NormTeamStats:
    provider: str
    provider_club_id: str
    season: str
    total_minutes_available: int = 0
    total_goals: int = 0
    matches_played: int = 0


# ---------------------------------------------------------------------------
# Engine outputs
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class RecoveryEstimate:
    injury_type: str
    min_weeks: float
    median_weeks: float
    max_weeks: float
    modifiers_applied: tuple[str, ...] = ()
    is_estimate: bool = field(default=True, init=False)
    disclaimer: str = field(default=MEDICAL_DISCLAIMER, init=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "injury_type": self.injury_type,
            "min_weeks": self.min_weeks,
            "median_weeks": self.median_weeks,
            "max_weeks": self.max_weeks,
            "modifiers_applied": list(self.modifiers_applied),
            "is_estimate": True,
            "disclaimer": self.disclaimer,
        }


@dataclass(frozen=True)
class ImpactComponents:
    """Everything needed to audit one injury score."""

    minutes_share: float
    goal_contribution_share: float
    replacement_gap: float
    fixture_difficulty: float
    weights: dict[str, float]
    raw_score: float                      # weighted sum in 0-1
    scale_max: float
    replacement_gap_defaulted: bool = False
    fixture_window_empty: bool = False
    fixtures_in_window: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "minutes_share": self.minutes_share,
            "goal_contribution_share": self.goal_contribution_share,
            "replacement_gap": self.replacement_gap,
            "fixture_difficulty": self.fixture_difficulty,
            "weights": dict(self.weights),
            "raw_score": self.raw_score,
            "scale_max": self.scale_max,
            "replacement_gap_defaulted": self.replacement_gap_defaulted,
            "fixture_window_empty": self.fixture_window_empty,
            "fixtures_in_window": self.fixtures_in_window,
        }


@dataclass(frozen=True)
class ImpactResult:
    injury_id: int
    score: float                          # 0-10
    components: ImpactComponents
    weights_version: str


@dataclass(frozen=True)
class ClubImpactResult:
    club_id: int
    score: float                          # 0-10
    contributions: tuple[dict[str, Any], ...]
    weights_version: str
    method: str = "diminishing_returns"
