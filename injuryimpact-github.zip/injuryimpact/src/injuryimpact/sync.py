"""One sync run: pick the due tasks, spend the API budget, ingest, score. DB glue around pure helpers.

Normal run  : squads (weekly) -> injuries (always) -> fixtures+standings (daily) -> player stats (daily).
Fast run    : injuries only, allowed to use the reserved last slice of the daily budget.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from .adapters.base import Adapter
from .budget import Budget
from .config import Settings
from .db import session_scope
from .models import ApiUsage, Fixture, PipelineRun, Player
from .pipeline import ingest_injuries, run_scoring, seed_recovery_ranges, sync_reference_data
from .planning import TASK_PARTS, choose_mode, due_tasks
from .recovery import RangeRow

PROVIDER = "api_football"
def load_budget(s: Session, settings: Settings, today: date) -> Budget:
    cfg = settings.providers[PROVIDER]
    row = s.get(ApiUsage, (PROVIDER, today))
    return Budget(cfg.daily_limit, settings.budget.normal_stop_fraction,
                  settings.budget.fast_mode_stop_fraction, row.calls_made if row else 0)


def save_budget(s: Session, settings: Settings, budget: Budget, today: date) -> None:
    row = s.get(ApiUsage, (PROVIDER, today)) or ApiUsage(provider=PROVIDER, usage_date=today,
                                                         daily_limit=settings.providers[PROVIDER].daily_limit)
    row.calls_made = budget.used
    s.add(row)


def is_matchday(s: Session, now: datetime) -> bool:
    return any((k if k.tzinfo else k.replace(tzinfo=timezone.utc)).date() == now.date()
               for k in s.scalars(select(Fixture.kickoff)).all())


def _last_done(s: Session, now: datetime) -> dict[str, datetime]:
    out: dict[str, datetime] = {}
    for run in s.scalars(select(PipelineRun).where(PipelineRun.status.in_(["success", "partial"]))
                         .order_by(PipelineRun.started_at)).all():
        done = (run.summary or {}).get("completed", [])
        for t in done:
            out[t] = run.started_at if run.started_at.tzinfo else run.started_at.replace(tzinfo=timezone.utc)
    return out


def run_sync(factory: sessionmaker[Session], make_adapter: Callable[[Budget, str], Adapter], settings: Settings,
             ranges: dict[str, RangeRow], mode: str, now: datetime) -> dict[str, Any]:
    """make_adapter(budget, mode) must return an adapter that shares the given Budget."""
    today = now.date()
    with session_scope(factory) as s:
        budget = load_budget(s, settings, today)
        run = PipelineRun(mode="matchday" if mode == "fast" else "scheduled", started_at=now)
        s.add(run); s.flush(); run_id = run.id
        tasks = due_tasks(mode, _last_done(s, now), s.scalar(select(Player.id).limit(1)) is not None, now)
    adapter = make_adapter(budget, mode)
    summary: dict[str, Any] = {"mode": mode, "planned": tasks, "completed": []}
    status, error = "success", None
    try:
        if hasattr(adapter, "sync_usage"):
            try:
                adapter.sync_usage()
            except Exception as e:                       # non-fatal: we still have our own count
                summary["usage_sync_error"] = str(e)
        with session_scope(factory) as s:
            seed_recovery_ranges(s, ranges)
            for task in tasks:
                if task == "injuries":
                    summary["injuries"] = ingest_injuries(s, adapter, settings, now, first_seen_start=True)
                else:
                    summary[task] = sync_reference_data(s, adapter, TASK_PARTS[task])
                if getattr(adapter, "partial", False):
                    status = "partial"; break            # budget ran out mid-task: do not mark it complete
                summary["completed"].append(task)
            summary["scoring"] = {"injuries_scored": run_scoring(s, settings, ranges, now)["injuries_scored"]}
        if getattr(adapter, "warnings", None):
            summary["warnings"] = adapter.warnings[:20]
    except Exception as e:                               # record the failure instead of losing it
        status, error = "failed", f"{type(e).__name__}: {e}"
    finally:
        with session_scope(factory) as s:
            run = s.get(PipelineRun, run_id)
            run.status, run.error, run.summary, run.finished_at = status, error, summary, datetime.now(timezone.utc)
            save_budget(s, settings, budget, today)
    summary.update(status=status, error=error, api_calls_today=budget.used)
    return summary
