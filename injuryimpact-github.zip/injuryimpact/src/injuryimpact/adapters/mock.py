"""Offline adapter reading data/mock/*.json (fictional clubs and players)."""
from __future__ import annotations

import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Optional

from ..types import (InjuryStatus, NormClub, NormFixture, NormInjury, NormPlayer, NormPlayerStats,
                     NormTeamStats, Position)
from .base import Adapter, AdapterError

DEFAULT_MOCK_DIR = Path(__file__).resolve().parents[3] / "data" / "mock"


def _dt(s: str) -> datetime:
    d = datetime.fromisoformat(s)
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


class MockAdapter(Adapter):
    name = "mock"

    def __init__(self, data_dir: Optional[Path | str] = None) -> None:
        self.dir = Path(data_dir or DEFAULT_MOCK_DIR)

    def _load(self, stem: str) -> list[dict[str, Any]]:
        path = self.dir / f"{stem}.json"
        try:
            data = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError) as e:
            raise AdapterError(f"Cannot read mock file {path}: {e}") from e
        if not isinstance(data, list):
            raise AdapterError(f"{path.name} must contain a JSON list.")
        return data

    def _parse(self, stem: str, fn):
        try:
            return [fn(r) for r in self._load(stem)]
        except (KeyError, ValueError, TypeError) as e:
            raise AdapterError(f"Malformed record in {stem}.json: {e!r}") from e

    def fetch_clubs(self) -> list[NormClub]:
        return self._parse("clubs", lambda r: NormClub(self.name, r["id"], r["name"], r.get("short_name")))

    def fetch_players(self) -> list[NormPlayer]:
        return self._parse("players", lambda r: NormPlayer(
            self.name, r["id"], r["club_id"], r["name"], Position(r["position"]),
            date.fromisoformat(r["date_of_birth"]) if r.get("date_of_birth") else None))

    def fetch_injuries(self) -> list[NormInjury]:
        return self._parse("injuries", lambda r: NormInjury(
            self.name, r["player_id"], r["club_id"], r["player_name"], r["injury_type_raw"],
            InjuryStatus(r["status"]), _dt(r["reported_at"]), r["source_name"], r["source_url"],
            date.fromisoformat(r["start_date"]) if r.get("start_date") else None))

    def fetch_fixtures(self) -> list[NormFixture]:
        return self._parse("fixtures", lambda r: NormFixture(
            self.name, r["id"], r["season"], int(r["gameweek"]), r["home_club_id"], r["away_club_id"],
            _dt(r["kickoff"]), r.get("difficulty_home"), r.get("difficulty_away"), r.get("status", "scheduled")))

    def fetch_player_stats(self) -> list[NormPlayerStats]:
        return self._parse("player_stats", lambda r: NormPlayerStats(
            self.name, r["player_id"], r["season"], r["minutes"], r["goals"], r["assists"],
            r["starts"], r["appearances"]))

    def fetch_team_stats(self) -> list[NormTeamStats]:
        return self._parse("team_stats", lambda r: NormTeamStats(
            self.name, r["club_id"], r["season"], r["total_minutes_available"], r["total_goals"],
            r["matches_played"]))
