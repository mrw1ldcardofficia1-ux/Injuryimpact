from .base import Adapter, AdapterError
from .api_football import ApiFootballAdapter
from .mock import MockAdapter

__all__ = ["Adapter", "AdapterError", "ApiFootballAdapter", "MockAdapter"]
