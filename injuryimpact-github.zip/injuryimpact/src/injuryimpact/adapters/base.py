"""Adapter contract. Adapters fetch and normalise; they never touch the database."""
from __future__ import annotations

from abc import ABC, abstractmethod

from ..types import NormClub, NormFixture, NormInjury, NormPlayer, NormPlayerStats, NormTeamStats


class AdapterError(RuntimeError):
    """Raised when a source returns data we cannot parse."""


class Adapter(ABC):
    name: str

    @abstractmethod
    def fetch_clubs(self) -> list[NormClub]: ...

    @abstractmethod
    def fetch_players(self) -> list[NormPlayer]: ...

    @abstractmethod
    def fetch_injuries(self) -> list[NormInjury]: ...

    # Optional endpoints: a source that lacks one returns an empty list.
    def fetch_fixtures(self) -> list[NormFixture]:
        return []

    def fetch_player_stats(self) -> list[NormPlayerStats]:
        return []

    def fetch_team_stats(self) -> list[NormTeamStats]:
        return []
