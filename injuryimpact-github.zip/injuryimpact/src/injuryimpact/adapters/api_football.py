"""API-Football v3 (api-sports.io) adapter. Reads only; never writes to the database.

Every HTTP call is counted against a Budget and throttled below the per-minute cap.
Fetch methods stop early (and set .partial) when the budget runs out instead of failing.
NOTE: written from the public docs; not yet run against the live API. Run `cli check-api` first.
"""
from __future__ import annotations

import re
import time
from datetime import date, datetime, timezone
from typing import Any, Callable, Optional

from ..budget import Budget, BudgetExceeded
from ..config import ProviderConfig, get_secret
from ..types import (InjuryStatus, NormClub, NormFixture, NormInjury, NormPlayer, NormPlayerStats,
                     NormTeamStats, Position)
from .base import Adapter, AdapterError

SOURCE_URL = "https://www.api-football.com/"
POSITIONS = {"Goalkeeper": Position.GK, "Defender": Position.DEF, "Midfielder": Position.MID, "Attacker": Position.FWD}
INJURY_STATUS = {"Missing Fixture": InjuryStatus.OUT, "Questionable": InjuryStatus.DOUBTFUL}
FINISHED, POSTPONED = {"FT", "AET", "PEN"}, {"PST"}
CANCELLED, LIVE = {"CANC", "ABD", "AWD", "WO"}, {"1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT", "SUSP"}


def _i(v: Any) -> int:
    return int(v) if v is not None else 0


class ApiFootballAdapter(Adapter):
    name = "api_football"

    def __init__(self, cfg: ProviderConfig, api_season: int, season_label: str, budget: Budget, *,
                 mode: str = "normal", api_key: Optional[str] = None, http: Any = None,
                 sleep: Callable[[float], None] = time.sleep, min_interval: float = 6.5,
                 now: Callable[[], datetime] = lambda: datetime.now(timezone.utc)) -> None:
        if http is None:
            import requests
            http = requests
        self.cfg, self.api_season, self.season, self.budget, self.mode = cfg, api_season, season_label, budget, mode
        self.key, self.http, self._sleep, self._gap, self._now = api_key or get_secret("API_FOOTBALL_KEY"), http, sleep, min_interval, now
        self._last = 0.0
        self.partial, self.warnings = False, []
        self._teams: Optional[list[dict]] = None
        self._standings: Optional[list[dict]] = None

    # ------------------------------------------------------------------ transport
    def _request(self, endpoint: str, params: dict[str, Any], counted: bool = True) -> dict[str, Any]:
        if counted and not self.budget.can_call(self.mode):
            raise BudgetExceeded(f"Daily budget reached ({self.budget.used}/{self.budget.limit}).")
        wait = self._gap - (time.monotonic() - self._last)
        if wait > 0:
            self._sleep(wait)
        self._last = time.monotonic()
        r = self.http.get(f"{self.cfg.base_url}/{endpoint}", headers={"x-apisports-key": self.key}, params=params, timeout=20)
        if counted:
            self.budget.record()                       # count even failures: the API does
        if r.status_code != 200:
            raise AdapterError(f"{endpoint}: HTTP {r.status_code}")
        body = r.json()
        if body.get("errors"):                         # API-Football reports errors inside a 200 response
            raise AdapterError(f"{endpoint}: {body['errors']}")
        return body

    def _get(self, endpoint: str, **params: Any) -> dict[str, Any]:
        return self._request(endpoint, params)

    def sync_usage(self) -> None:
        """Ask /status for today's real usage (this call is not counted by the API)."""
        req = self._request("status", {}, counted=False).get("response", {}).get("requests", {})
        if isinstance(req, dict) and req.get("current") is not None:
            self.budget.used = max(self.budget.used, int(req["current"]))

    def _league(self) -> dict[str, Any]:
        return {"league": self.cfg.league_id, "season": self.api_season}

    # ------------------------------------------------------------------ endpoints
    def _team_rows(self) -> list[dict]:
        if self._teams is None:
            self._teams = self._get("teams", **self._league()).get("response", [])
        return self._teams

    def fetch_clubs(self) -> list[NormClub]:
        out = []
        for row in self._team_rows():
            t = row.get("team") or {}
            if t.get("id") is None or not t.get("name"):
                raise AdapterError(f"teams: malformed row {row!r}")
            short = t.get("code") or f"{t['name'][:3].upper()}{t['id']}"
            out.append(NormClub(self.name, str(t["id"]), t["name"], short[:10]))
        return out

    def fetch_players(self) -> list[NormPlayer]:
        out: list[NormPlayer] = []
        for row in self._team_rows():
            tid = str(row["team"]["id"])
            try:
                body = self._get("players/squads", team=tid)
            except BudgetExceeded:
                self.partial = True
                break
            for squad in body.get("response", []):
                for p in squad.get("players", []):
                    pos = POSITIONS.get(p.get("position") or "")
                    if pos is None:
                        self.warnings.append(f"squad player {p.get('id')}: unknown position {p.get('position')!r}")
                    out.append(NormPlayer(self.name, str(p["id"]), tid, p["name"], pos, None))   # API gives age, not date of birth
        return out

    def fetch_injuries(self) -> list[NormInjury]:
        earliest: dict[str, tuple[str, dict]] = {}
        for item in self._get("injuries", **self._league()).get("response", []):
            p, t = item.get("player") or {}, item.get("team") or {}
            if p.get("id") is None or t.get("id") is None:
                raise AdapterError(f"injuries: malformed row {item!r}")
            when = (item.get("fixture") or {}).get("date") or ""
            key = str(p["id"])
            if key not in earliest or when < earliest[key][0]:      # one entry per upcoming fixture: keep the soonest
                earliest[key] = (when, item)
        now, out = self._now(), []
        for key, (_, item) in earliest.items():
            p, t = item["player"], item["team"]
            status = INJURY_STATUS.get(p.get("type") or "")
            if status is None:
                self.warnings.append(f"injury for player {key}: unknown type {p.get('type')!r}, skipped")
                continue
            out.append(NormInjury(self.name, key, str(t["id"]), p.get("name") or "", p.get("reason") or "", status, now,
                                  self.name, SOURCE_URL, None))      # API has no start date; pipeline uses first-seen
        return out

    def _standings_rows(self) -> list[dict]:
        if self._standings is None:
            resp = self._get("standings", **self._league()).get("response", [])
            self._standings = resp[0]["league"]["standings"][0] if resp and resp[0].get("league", {}).get("standings") else []
        return self._standings

    def _strength(self) -> dict[str, float]:
        rows = self._standings_rows()
        n = len(rows)
        return {str(r["team"]["id"]): 1 - (int(r["rank"]) - 1) / (n - 1) for r in rows} if n > 1 else {}

    def fetch_fixtures(self) -> list[NormFixture]:
        strength, out = self._strength(), []
        for f in self._get("fixtures", **self._league()).get("response", []):
            m = re.search(r"(\d+)\s*$", (f.get("league") or {}).get("round") or "")
            fx, teams = f.get("fixture") or {}, f.get("teams") or {}
            if not m or fx.get("id") is None or not fx.get("date"):
                self.warnings.append(f"fixture skipped: {fx.get('id')}"); continue
            h, a = str(teams["home"]["id"]), str(teams["away"]["id"])
            short = (fx.get("status") or {}).get("short") or "NS"
            status = ("finished" if short in FINISHED else "postponed" if short in POSTPONED
                      else "cancelled" if short in CANCELLED else "live" if short in LIVE else "scheduled")
            dh = round(max(0.0, strength[a] - 0.1), 2) if a in strength else None   # opponent strength, home edge
            da = round(min(1.0, strength[h] + 0.1), 2) if h in strength else None
            out.append(NormFixture(self.name, str(fx["id"]), self.season, int(m.group(1)), h, a,
                                   datetime.fromisoformat(fx["date"]), dh, da, status))
        return out

    def fetch_team_stats(self) -> list[NormTeamStats]:
        out = []
        for r in self._standings_rows():
            played = _i((r.get("all") or {}).get("played"))
            out.append(NormTeamStats(self.name, str(r["team"]["id"]), self.season, played * 90,
                                     _i(((r.get("all") or {}).get("goals") or {}).get("for")), played))
        return out

    def fetch_player_stats(self) -> list[NormPlayerStats]:
        out, page, total = [], 1, 1
        while page <= total:
            try:
                body = self._get("players", page=page, **self._league())
            except BudgetExceeded:
                self.partial = True
                break
            total = int((body.get("paging") or {}).get("total") or 1)
            for row in body.get("response", []):
                st = row.get("statistics") or []
                g = lambda k, sub: sum(_i((s.get(k) or {}).get(sub)) for s in st)   # noqa: E731
                out.append(NormPlayerStats(
                    self.name, str(row["player"]["id"]), self.season, g("games", "minutes"), g("goals", "total"),
                    g("goals", "assists"), g("games", "lineups"),
                    g("games", "appearences") or g("games", "appearances")))        # the API spells it "appearences"
            page += 1
        return out
