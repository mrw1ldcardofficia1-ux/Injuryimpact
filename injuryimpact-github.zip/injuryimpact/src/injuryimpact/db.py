"""Engine and session helpers. SQLite for local dev, Postgres/Supabase in production."""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from typing import Iterator, Optional

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from .models import Base

DEFAULT_URL = "sqlite:///injuryimpact.db"


def get_database_url() -> str:
    url = os.environ.get("DATABASE_URL", DEFAULT_URL)
    # Supabase/Heroku-style URLs: make SQLAlchemy use the psycopg v3 driver.
    if url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url[len("postgres://"):]
    elif url.startswith("postgresql://"):
        url = "postgresql+psycopg://" + url[len("postgresql://"):]
    return url


@event.listens_for(Engine, "connect")
def _sqlite_enable_fk(dbapi_connection, _record) -> None:
    # SQLite ignores foreign keys unless this pragma is set per connection.
    if isinstance(dbapi_connection, sqlite3.Connection):
        cur = dbapi_connection.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()


def make_engine(url: Optional[str] = None, echo: bool = False) -> Engine:
    return create_engine(url or get_database_url(), echo=echo, future=True)


def init_db(engine: Engine) -> None:
    """Create all tables. For Postgres in production prefer migrations/*.sql."""
    Base.metadata.create_all(engine)


def make_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, expire_on_commit=False)


@contextmanager
def session_scope(factory: sessionmaker[Session]) -> Iterator[Session]:
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
